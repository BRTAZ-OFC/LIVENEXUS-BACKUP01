import VoiceControls from '@dashboard/configuracao/Config_VoiceControls';

export default function VoiceSection({ settings, voices, speaking, onChange, onToggle, onClear }) {
  return (
    <div className="space-y-5">
      <header>
        <h2 className="text-lg font-semibold text-white">Voz & TTS</h2>
        <p className="text-sm text-slate-400">Motor de voz local do navegador · zero créditos</p>
      </header>
      <VoiceControls settings={settings} voices={voices} speaking={speaking} onChange={onChange} onToggle={onToggle} onClear={onClear} />
    </div>
  );
}