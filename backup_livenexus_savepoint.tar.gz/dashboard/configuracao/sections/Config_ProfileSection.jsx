// ProfileSection — área de Perfil do usuário no LiveNexus.
// Mostra e edita avatar + nome de exibição (persistência pontual via updateMe).
// NÃO há polling, autosync ou requests recorrentes.
import React, { useState, useEffect } from 'react';
import { useAuth } from '@dashboard/login/AuthContext';
import { useNewUserDataCentral } from '@dashboard/configuracao/DataCentral_NewUserDataCentral';
import { useStreaming } from '@dashboard/configuracao/Config_StreamingContext';
import { User, Camera, Save, X, Loader2, Pencil, Trash2, Radio } from 'lucide-react';
import { liveSessionService } from '@dashboard/configuracao/Config_liveSessionService';
import LiveSessionCard from '@dashboard/configuracao/Config_LiveSessionCard';
import LiveSessionDialog from '@dashboard/configuracao/Config_LiveSessionDialog';
import { useAvatar, setAvatarUrl, removeAvatar } from '@dashboard/configuracao/avatar/Config_avatarStorageAdapter';
import UserGallerySection from '@dashboard/configuracao/sections/Config_UserGallerySection';
import GalleryPicker from '@dashboard/componentes/GalleryPicker';

export default function ProfileSection({ onNavigateToAllLives }) {
  const { user, updateUser } = useAuth();
  const { pastLives, removePastLive } = useStreaming();
  const central = useNewUserDataCentral();
  const [editing, setEditing] = useState(false);
  const [displayName, setDisplayName] = useState('');
  const [saving, setSaving] = useState(false);
  const avatarUrl = useAvatar();
  const [nameWarning, setNameWarning] = useState('');
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [lives, setLives] = useState(central.sessions);
  const [livesLoading, setLivesLoading] = useState(central.isLoading);
  const [openSession, setOpenSession] = useState(null);
  const [editSession, setEditSession] = useState(null);
  const [deleteId, setDeleteId] = useState(null);
  const [savingPending, setSavingPending] = useState(null);

  useEffect(() => {
    setLives(central.sessions);
    setLivesLoading(central.isLoading);
  }, [central.sessions, central.isLoading]);

  const handleDeleteLive = async () => {
    if (!deleteId) return;
    try {
      await liveSessionService.deleteSession(deleteId, null);
      setLives(prev => prev.filter(l => l.id !== deleteId));
      setDeleteId(null);
    } catch (e) { console.error(e); }
  };

  // Inicializa campos do formulário a partir dos dados do usuário
  useEffect(() => {
    if (user) {
      setDisplayName(user.data?.display_name || user.full_name || '');
    }
  }, [user]);

  const handleSave = async () => {
    const trimmed = displayName.trim();
    if (!trimmed || trimmed.length > 8) return;
    const originalName = user?.data?.display_name || user?.full_name || '';
    if (trimmed === originalName) { setEditing(false); return; }
    setSaving(true);
    try {
      const newData = { ...(user.data || {}), display_name: trimmed };
      await fetch('/api/auth/update-me', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ data: newData }),
      });
      updateUser({ data: newData });
      setEditing(false);
      setNameWarning('');
    } catch (e) {
      console.error('Profile save failed:', e);
    }
    setSaving(false);
  };

  const handleCancel = () => {
    setDisplayName(user?.data?.display_name || user?.full_name || '');
    setEditing(false);
    setNameWarning('');
  };

  const handleSelectAvatar = async (url) => {
    setAvatarUrl(url);
    try {
      const newData = { ...(user.data || {}), avatar_url: url };
      await fetch('/api/auth/update-me', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ data: newData }),
      });
      updateUser({ data: newData });
    } catch (e) {
      console.error('Avatar save failed:', e);
    }
  };

  const handleRemoveAvatar = async () => {
    removeAvatar();
    try {
      const newData = { ...(user.data || {}), avatar_url: null };
      await fetch('/api/auth/update-me', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ data: newData }),
      });
      updateUser({ data: newData });
    } catch (e) {
      console.error('Avatar remove failed:', e);
    }
  };

  // Última Live pendente — salvar (persiste LiveSession) ou descartar (remove pendência).
  // Reaproveita a mesma lógica que estava no Dashboard: saveSession + removePastLive + reload.
  const handleSavePending = async (live) => {
    const key = live.platform + '-' + live.streamId;
    setSavingPending(key);
    try {
      const duration = live.startedAt && live.endedAt
        ? Math.round((new Date(live.endedAt) - new Date(live.startedAt)) / 1000)
        : null;
      const created = await liveSessionService.saveSession(null, {
        title: live.title || 'Transmissão',
        platform: live.platform || null,
        platforms: live.platform ? [live.platform] : [],
        streamId: live.streamId || null,
        vodId: live.vodId || null,
        vodStatus: live.vodId ? 'available' : 'pending',
        streamUrl: live.streamUrl || null,
        thumbnailUrl: live.thumbnailUrl || null,
        channelName: live.channelName || null,
        startedAt: live.startedAt || null,
        endedAt: live.endedAt || null,
        duration,
        views: null,
      });
      removePastLive(live.streamId, live.platform);
      setLives(prev => [created, ...prev]);
    } catch (e) {
      console.error('Failed to save pending live:', e);
    }
    setSavingPending(null);
  };

  const handleDiscardPending = (live) => {
    removePastLive(live.streamId, live.platform);
  };

  const avatar = avatarUrl || user?.data?.avatar_url;
  const name = user?.data?.display_name || user?.full_name || user?.email || 'Usuário';

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Cabeçalho do Perfil */}
      <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
        <div className="flex flex-col items-center gap-5 sm:flex-row">
          {/* Avatar */}
          <div className="relative shrink-0">
            {avatar ? (
              <img src={avatar} alt={name} className="h-20 w-20 rounded-full object-cover ring-2 ring-violet-500/30" />
            ) : (
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-violet-500/20 ring-2 ring-violet-500/30">
                <User size={32} className="text-violet-300" />
              </div>
            )}
            {editing && (
              <>
                <button
                  onClick={() => setGalleryOpen(true)}
                  className="absolute -bottom-1 -right-1 flex h-7 w-7 items-center justify-center rounded-full bg-violet-500 text-white shadow-lg transition hover:bg-violet-600"
                  title="Escolher da galeria"
                >
                  <Camera size={14} />
                </button>
                {avatar && (
                  <button
                    onClick={handleRemoveAvatar}
                    className="absolute -bottom-1 -left-1 flex h-7 w-7 items-center justify-center rounded-full bg-red-500 text-white shadow-lg transition hover:bg-red-600"
                    title="Remover avatar"
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </>
            )}
          </div>

          {/* Nome + email */}
          <div className="flex-1 min-w-0 text-center sm:text-left">
            {editing ? (
              <div>
                <input
                  type="text"
                  value={displayName}
                  onChange={e => {
                    const val = e.target.value;
                    if (val.length > 8) {
                      setDisplayName(val.slice(0, 8));
                      setNameWarning('Excedeu o limite de 8 caracteres.');
                    } else {
                      setDisplayName(val);
                      setNameWarning('');
                    }
                  }}
                  placeholder="Nome de exibição"
                  className="w-full rounded-lg border border-white/10 bg-black/30 px-3 py-2 text-lg font-semibold text-white outline-none focus:border-violet-500"
                />
                <div className="mt-1 flex items-center justify-between">
                  <span className={`text-[11px] ${nameWarning ? 'text-amber-400' : 'text-slate-500'}`}>
                    {nameWarning || '\u00A0'}
                  </span>
                  <span className="text-[11px] text-slate-500">{displayName.length}/8</span>
                </div>
              </div>
            ) : (
              <h2 className="text-xl font-bold text-white truncate">{name}</h2>
            )}
            <p className="mt-0.5 text-sm text-slate-400 truncate">{user?.email}</p>
            {user?.role === 'admin' && <span className="mt-1 inline-block rounded-full bg-violet-500/20 px-2 py-0.5 text-[10px] font-medium text-violet-300">Administrador</span>}
          </div>

          {/* Botões Editar / Salvar */}
          <div className="shrink-0">
            {editing ? (
              <div className="flex gap-2">
                <button onClick={handleSave} disabled={saving || !displayName.trim() || displayName.trim().length > 8} className="flex items-center gap-1.5 rounded-lg bg-violet-500 px-3 py-2 text-xs font-medium text-white transition hover:bg-violet-600 disabled:opacity-50">
                  {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} Salvar
                </button>
                <button onClick={handleCancel} className="flex items-center gap-1.5 rounded-lg bg-white/5 px-3 py-2 text-xs text-slate-300 transition hover:bg-white/10">
                  <X size={14} /> Cancelar
                </button>
              </div>
            ) : (
              <button onClick={() => setEditing(true)} className="flex items-center gap-1.5 rounded-lg bg-white/5 px-3 py-2 text-xs font-medium text-slate-200 transition hover:bg-white/10">
                <Pencil size={14} /> Editar perfil
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Última Live pendente — salvar ou descartar (descoberta de VOD falhou) */}
      {pastLives.length > 0 && (
        <div className="rounded-2xl border border-amber-500/20 bg-amber-500/[0.03] p-6">
          <div className="mb-4 flex items-center gap-2">
            <Radio size={18} className="text-amber-400" />
            <h3 className="text-lg font-semibold text-white">Última Live</h3>
            <span className="ml-auto text-xs text-amber-400/80">pendente</span>
          </div>
          <div className="space-y-2">
            {pastLives.map(l => {
              const key = l.platform + '-' + l.streamId;
              return (
                <div key={key} className="flex items-center gap-3 rounded-xl border border-amber-500/20 bg-amber-500/5 p-3">
                  <div className="h-10 w-16 shrink-0 overflow-hidden rounded-lg bg-black/60">
                    {l.thumbnailUrl ? (
                      <img src={l.thumbnailUrl} alt={l.title} className="h-full w-full object-cover" />
                    ) : (
                      <div className="flex h-full w-full items-center justify-center text-[9px] text-slate-600">LIVE</div>
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-white">{l.title}</p>
                    <p className="truncate text-[11px] text-slate-400">{l.platform} · {l.channelName}</p>
                  </div>
                  <div className="flex shrink-0 gap-2">
                    <button onClick={() => handleSavePending(l)} disabled={savingPending === key} className="flex items-center gap-1 rounded-lg bg-violet-500 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-violet-600 disabled:opacity-50">
                      {savingPending === key ? <Loader2 size={12} className="animate-spin" /> : <Save size={12} />} Salvar
                    </button>
                    <button onClick={() => handleDiscardPending(l)} className="flex items-center gap-1 rounded-lg bg-white/5 px-3 py-1.5 text-xs text-slate-300 transition hover:bg-white/10">
                      <Trash2 size={12} /> Descartar
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Minhas Lives */}
      <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
        <div className="mb-4 flex items-center gap-2">
          <Radio size={18} className="text-violet-300" />
          <h3 className="text-lg font-semibold text-white">Minhas Lives</h3>
          <span className="ml-auto text-xs text-slate-500">{lives.length} live(s)</span>
        </div>
        {livesLoading ? (
          <div className="flex justify-center py-8"><Loader2 className="animate-spin text-slate-500" size={24} /></div>
        ) : lives.length === 0 ? (
          <div className="py-8 text-center text-sm text-slate-500">Nenhuma live salva ainda.</div>
        ) : (
          <>
            <div className="grid gap-3 sm:grid-cols-2">
              {lives.slice(0, 4).map(s => (
                <LiveSessionCard key={s.id} session={s} onOpen={setOpenSession} onEdit={setEditSession} onDelete={(id) => setDeleteId(id)} />
              ))}
            </div>
            {lives.length > 4 && onNavigateToAllLives && (
              <button onClick={onNavigateToAllLives} className="mt-4 w-full rounded-lg bg-white/5 py-2 text-sm font-medium text-violet-300 transition hover:bg-violet-500/10">
                Ver mais ({lives.length})
              </button>
            )}
          </>
        )}
      </div>

      {/* Minha Galeria */}
      <UserGallerySection />

      {/* Seletor de galeria para avatar */}
      <GalleryPicker open={galleryOpen} onClose={() => setGalleryOpen(false)} onSelect={handleSelectAvatar} title="Escolher Avatar" />

      {/* Dialog de Live */}
      {openSession && <LiveSessionDialog session={openSession} open onClose={() => setOpenSession(null)} />}
      {editSession && <LiveSessionDialog session={editSession} open edit onClose={() => setEditSession(null)} onSave={(updated) => setLives(prev => prev.map(l => l.id === updated.id ? updated : l))} />}
      {deleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" onClick={() => setDeleteId(null)}>
          <div className="w-full max-w-sm rounded-2xl border border-white/10 bg-[#0a0d15] p-6" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-white">Apagar live?</h3>
            <p className="mt-2 text-sm text-slate-400">Esta ação não pode ser desfeita.</p>
            <div className="mt-4 flex gap-2">
              <button onClick={handleDeleteLive} className="flex-1 rounded-lg bg-red-500 py-2 text-sm font-medium text-white transition hover:bg-red-600">Apagar</button>
              <button onClick={() => setDeleteId(null)} className="flex-1 rounded-lg bg-white/5 py-2 text-sm text-slate-300 transition hover:bg-white/10">Cancelar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}