import React, { useEffect, useState } from 'react';

const zones = typeof Intl.supportedValuesOf === 'function'
  ? Intl.supportedValuesOf('timeZone')
  : ['America/Sao_Paulo', 'America/New_York', 'Europe/Lisbon', 'UTC'];

export default function ManualWidgetConfig({ instance, onUpdateInstance }) {
  const id = instance.widgetId;
  const config = instance.config || {};
  const save = patch => onUpdateInstance(instance.id, { config: { ...config, ...patch } });
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    if (id !== 'manual-timer' || !config.timerRunning) return undefined;
    const interval = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(interval);
  }, [id, config.timerRunning]);

  if (id === 'manual-death-counter') {
    const count = Math.max(0, Number(config.deathCount) || 0);
    return <div className="space-y-3 text-xs text-slate-300">
      <span className="block font-semibold">Contador de Mortes</span>
      <div className="flex items-center gap-2">
        <button type="button" aria-label="Diminuir mortes" onClick={() => save({ deathCount: Math.max(0, count - 1) })}
          className="rounded-lg border border-white/20 bg-slate-900 px-3 py-2 text-white hover:bg-slate-800">−</button>
        <output className="min-w-12 text-center text-lg font-bold tabular-nums text-white">{count}</output>
        <button type="button" aria-label="Aumentar mortes" onClick={() => save({ deathCount: count + 1 })}
          className="rounded-lg border border-white/20 bg-slate-900 px-3 py-2 text-white hover:bg-slate-800">+</button>
        <button type="button" onClick={() => save({ deathCount: 0 })}
          className="rounded-lg border border-white/20 bg-slate-900 px-3 py-2 text-white hover:bg-slate-800">Resetar</button>
      </div>
    </div>;
  }

  if (id === 'manual-clock') return <label className="block space-y-2 text-xs text-slate-300">
    <span>Fuso horário do relógio</span>
    <select value={config.timeZone || ''} onChange={event => save({ timeZone: event.target.value })}
      className="w-full rounded-lg border border-white/20 bg-slate-900 px-3 py-2 text-white">
      <option value="">Fuso do dispositivo</option>
      {!zones.includes('UTC') && <option value="UTC">UTC</option>}
      {zones.map(zone => <option key={zone} value={zone}>{zone.replaceAll('_', ' ')}</option>)}
    </select>
  </label>;

  if (id !== 'manual-timer') return null;

  const duration = Math.max(0, Number(config.durationSeconds ?? 300));
  const remaining = config.timerRunning && Number.isFinite(Number(config.timerEndAt))
    ? Math.max(0, (Number(config.timerEndAt) - now) / 1000)
    : Math.max(0, Number(config.remainingSeconds ?? duration));
  const running = Boolean(config.timerRunning && remaining > 0);
  const updateDuration = (minutes, seconds) => {
    const total = Math.max(0, Math.floor(minutes) * 60 + Math.floor(seconds));
    save({ durationSeconds: total, remainingSeconds: total, timerRunning: false, timerEndAt: null });
  };
  const start = () => {
    const seconds = remaining > 0 ? remaining : duration;
    if (seconds <= 0) return;
    const currentTime = Date.now();
    setNow(currentTime);
    save({ timerRunning: true, timerEndAt: currentTime + seconds * 1000, remainingSeconds: seconds });
  };
  const pause = () => save({ timerRunning: false, remainingSeconds: remaining, timerEndAt: null });
  const reset = () => save({ timerRunning: false, remainingSeconds: duration, timerEndAt: null });
  return <div className="space-y-2 text-xs text-slate-300">
    <span>Tempo inicial do temporizador</span>
    <div className="grid grid-cols-2 gap-2">
      <label className="space-y-1"><span className="block">Minutos</span>
        <input type="number" min="0" max="9999" value={Math.floor(duration / 60)}
          onChange={event => updateDuration(Number(event.target.value) || 0, duration % 60)}
          className="w-full rounded-lg border border-white/20 bg-slate-900 px-3 py-2 text-white" />
      </label>
      <label className="space-y-1"><span className="block">Segundos</span>
        <input type="number" min="0" max="59" value={duration % 60}
          onChange={event => updateDuration(Math.floor(duration / 60), Math.min(59, Number(event.target.value) || 0))}
          className="w-full rounded-lg border border-white/20 bg-slate-900 px-3 py-2 text-white" />
      </label>
    </div>
    <div className="flex items-center gap-2 pt-1">
      <output className="min-w-16 text-base font-bold tabular-nums text-white">{Math.ceil(remaining)}s</output>
      <button type="button" onClick={running ? pause : start} disabled={!running && duration <= 0}
        className="rounded-lg border border-white/20 bg-slate-900 px-3 py-2 text-white hover:bg-slate-800 disabled:opacity-50">
        {running ? 'Pausar' : 'Iniciar'}
      </button>
      <button type="button" onClick={reset}
        className="rounded-lg border border-white/20 bg-slate-900 px-3 py-2 text-white hover:bg-slate-800">Resetar</button>
    </div>
  </div>;
}
