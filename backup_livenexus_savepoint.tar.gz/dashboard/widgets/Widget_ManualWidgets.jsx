import React, { useEffect, useState } from 'react';
import { getCurrentTrack } from '@dashboard/biblioteca/Library_youtubePlayer';
import { playerEvents } from '@dashboard/biblioteca/Library_playerEvents';

const shells = [
  'rounded-xl bg-slate-950/90 border border-slate-500/40 text-white p-4',
  'rounded-full bg-indigo-950/90 border-2 border-indigo-400 text-indigo-100 px-6 py-3',
  'rounded-none bg-black border-l-4 border-lime-400 text-lime-300 p-4 font-mono',
  'rounded-2xl bg-gradient-to-r from-purple-950 via-fuchsia-900 to-slate-950 border border-fuchsia-400/70 text-white p-4',
  'rounded-lg bg-white/95 border border-slate-300 text-slate-900 p-4 shadow-lg'
];

function Frame({ config, children, label, className = '' }) {
  const style = Math.max(0, Math.min(5, Number(config.structuralPreset) || 0));
  return <div className={`w-full h-full min-w-0 overflow-hidden flex ${style === 2 ? 'items-center justify-between gap-3' : style === 4 ? 'items-center justify-center gap-3' : 'flex-col justify-center gap-2'} ${shells[style ? style - 1 : 0]} ${className}`} style={{ fontFamily: config.fontFamily || 'Inter, sans-serif' }}>
    {label && style !== 5 && <span className="text-[10px] font-bold uppercase tracking-[.17em] opacity-70">{label}</span>}
    {children}
  </div>;
}

export function DeathCounter({ config = {}, elementKey }) {
  const count = Math.max(0, Number(config.deathCount) || 0);
  return <Frame config={config} label={elementKey === 'count' ? null : 'Mortes'}>
    <strong className="text-4xl leading-none tabular-nums">{count}</strong>
  </Frame>;
}

export function ClockWidget({ config = {}, elementKey }) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => { const id = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(id); }, []);
  const zone = config.timeZone || Intl.DateTimeFormat().resolvedOptions().timeZone;
  let time, date;
  try {
    time = new Intl.DateTimeFormat('pt-BR', { timeZone: zone, hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(now);
    date = new Intl.DateTimeFormat('pt-BR', { timeZone: zone, day: '2-digit', month: 'long' }).format(now);
  } catch {
    time = new Intl.DateTimeFormat('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(now);
    date = '';
  }
  return <Frame config={config} label={elementKey ? null : 'Relógio'}>
    {elementKey !== 'date' && <time className="text-3xl font-bold leading-none tabular-nums">{time}</time>}
    {elementKey !== 'time' && (elementKey === 'date' || Number(config.structuralPreset) !== 5) && <span className="text-xs opacity-70">{date}</span>}
  </Frame>;
}

function formatDuration(seconds) {
  const n = Math.max(0, Math.ceil(seconds));
  return `${String(Math.floor(n / 3600)).padStart(2, '0')}:${String(Math.floor(n % 3600 / 60)).padStart(2, '0')}:${String(n % 60).padStart(2, '0')}`;
}

export function TimerWidget({ config = {}, elementKey }) {
  const [now, setNow] = useState(() => Date.now());
  const initial = Math.max(0, Number(config.durationSeconds ?? 300));
  const remaining = config.timerRunning && Number.isFinite(Number(config.timerEndAt))
    ? Math.max(0, (Number(config.timerEndAt) - now) / 1000)
    : Math.max(0, Number(config.remainingSeconds ?? initial));
  useEffect(() => {
    if (!config.timerRunning) return undefined;
    const id = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(id);
  }, [config.timerRunning]);
  return <Frame config={config} label={elementKey === 'timer' ? null : 'Temporizador'}>
    <strong className="text-3xl leading-none tabular-nums">{formatDuration(remaining)}</strong>
  </Frame>;
}

function useExistingTrack() {
  const [track, setTrack] = useState(() => getCurrentTrack());
  useEffect(() => {
    const refresh = () => setTrack(getCurrentTrack());
    const off = ['track_changed', 'track_started', 'track_resumed', 'track_paused', 'track_finished', 'queue_empty'].map(event => playerEvents.on(event, refresh));
    let channel;
    const fromState = data => { if (data?.type === 'music_state') setTrack(data.track || null); };
    try {
      channel = new BroadcastChannel('streamspeak_music');
      channel.onmessage = event => fromState(event.data);
      channel.postMessage({ type: 'music_request_state' });
    } catch { /* Player may be in the same tab. */ }
    const onStorage = event => {
      if (event.key === 'streamspeak_music_state' && event.newValue) {
        try { fromState(JSON.parse(event.newValue)); } catch { /* Invalid old state. */ }
      }
    };
    window.addEventListener('storage', onStorage);
    return () => { off.forEach(unsubscribe => unsubscribe()); channel?.close(); window.removeEventListener('storage', onStorage); };
  }, []);
  return track;
}

export function NowPlayingWidget({ config = {}, elementKey }) {
  const track = useExistingTrack();
  const title = track?.title || 'Nada tocando';
  const artist = track?.artist || track?.artistName;
  const image = track?.thumbnail || track?.cover || track?.image;
  const nameOnly = Number(config.structuralPreset) === 5 || elementKey === 'title';
  return <Frame config={config} label={nameOnly || elementKey ? null : 'Tocando agora'}>
    {(elementKey === 'cover' || (!elementKey && !nameOnly)) && image && <img src={image} alt="" className="h-9 w-9 rounded object-cover shrink-0" />}
    {elementKey !== 'artist' && elementKey !== 'cover' && <div className="w-full min-w-0 overflow-hidden" aria-label={title}>
      <style>{'@keyframes ln-track-marquee { from { transform: translateX(100%); } to { transform: translateX(-100%); } }'}</style>
      <span className="block w-max min-w-full whitespace-nowrap font-bold text-lg" style={{ animation: 'ln-track-marquee 12s linear infinite' }}>{title}</span>
    </div>}
    {(elementKey === 'artist' || (!elementKey && !nameOnly)) && artist && <span className="text-xs opacity-70 truncate max-w-full">{artist}</span>}
  </Frame>;
}

const components = {
  'manual-death-counter': DeathCounter,
  'manual-clock': ClockWidget,
  'manual-timer': TimerWidget,
  'manual-now-playing': NowPlayingWidget
};

const labels = {
  'manual-death-counter': ['Placar de Mortes', 'Pílula Compacta', 'Terminal de Mortes', 'Neon Gamer', 'Minimal Claro'],
  'manual-clock': ['Relógio Digital', 'Fuso Compacto', 'Terminal Horário', 'Relógio Neon', 'Hora Minimal'],
  'manual-timer': ['Contagem Principal', 'Timer Compacto', 'Terminal Regressivo', 'Timer Neon', 'Tempo Minimal'],
  'manual-now-playing': ['Player Discreto', 'Faixa Compacta', 'Terminal Musical', 'Neon Musical', 'Só Nome em Marquee']
};

export const MANUAL_WIDGET_TEMPLATES = Object.fromEntries(Object.entries(components).map(([id, Component]) => [id,
  labels[id].map((name, index) => ({
    id: String(index + 1).padStart(2, '0'), number: index + 1, name,
    description: name, badge: name, aspectRatio: '320x120',
    defaultWidth: 320, defaultHeight: 120,
    render: ({ config = {} }) => <Component config={{ ...config, structuralPreset: String(index + 1).padStart(2, '0') }} />
  }))
]));
