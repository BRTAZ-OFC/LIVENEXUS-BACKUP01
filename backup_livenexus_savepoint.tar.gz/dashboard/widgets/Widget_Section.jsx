import React from 'react';
import { useStreaming } from '@dashboard/configuracao/Config_StreamingContext';
import { TWITCH_WIDGETS_CATALOG } from './Widget_twitchWidgetsCatalog';
import { MULTIPLATFORM_WIDGET_IDS } from '@dashboard/overlays/Overlay_platformData';
import { Activity, AlertCircle, ArrowRight } from 'lucide-react';

const WIDGET_DESCRIPTIONS = {
  'manual-death-counter': 'Contador manual; controle o valor no Config do editor.',
  'manual-clock': 'Exibe o horário atual no fuso escolhido no Config do editor.',
  'manual-timer': 'Contagem regressiva controlada pelo Config do editor.',
  'manual-now-playing': 'Mostra a faixa do player existente; o título permanece em movimento.',
  'youtube-native-poll': 'Exibe uma enquete nativa recebida do YouTube pelo fluxo global; não utiliza comandos de chat.',
  'twitch-chat-box': 'Renderiza as mensagens recebidas em tempo real do chat de forma sequencial com filtros de badges/roles.',
  'twitch-alerts': 'Exibe notificações gráficas animadas para eventos como subs, bits, resubs, community subgifts e raids.',
  'twitch-event-list': 'Apresenta um histórico dinâmico dos últimos eventos ocorridos na transmissão de forma consolidada.',
  'twitch-status-label': 'Exibe estatísticas de visualização ativa, título e categoria da transmissão atual.',
  'twitch-sub-goal': 'Meta visual para engajar a comunidade a alcançar um objetivo de novos inscritos.',
  'twitch-bits-goal': 'Barra de progresso interativa para incentivar o envio de bits na transmissão.',
  'twitch-raid-goal': 'Monitore o progresso para alcançar a meta de raids recebidas na live.',
  'twitch-latest-sub': 'Exibe o nome e o nível do usuário mais recente a se inscrever no canal.',
  'twitch-latest-cheer': 'Mostra o remetente e a quantia de bits do último cheer recebido.',
  'twitch-latest-raid': 'Identifica e exibe a última raid que visitou a transmissão com a quantidade de viewers.',
  'twitch-top-cheer': 'Exibe o maior envio individual de bits realizado durante toda a stream.',
  'twitch-sub-counter': 'Contador limpo e minimalista do número de inscrições ativas da sessão.',
  'twitch-bits-counter': 'Contador acumulativo em tempo real do total de bits enviados na transmissão.',
  'twitch-chat-speed': 'Calcula e exibe a velocidade atual de envio de mensagens no chat em tempo real.',
  'twitch-hype-meter': 'Medidor gráfico de empolgação e engajamento da stream baseado na atividade de chat e eventos.',
  'twitch-chat-vibe': 'Analisador de sentimento inteligente que mede a vibe do chat por meio de palavras-chave e emojis.',
  'twitch-viewers-chart': 'Gráfico histórico interativo em tempo real das flutuações na contagem de espectadores.',
  'twitch-chatter-leaderboard': 'Ranking dos espectadores mais ativos e engajados que mais enviaram mensagens.',
  'twitch-poll': 'Cria e exibe enquetes que computam votos do chat em tempo real pelo comando !voto <opção>.',
  'twitch-raffle': 'Widget de sorteio com adesão via !entrar no chat e escolha de vencedor com animações.',
  'twitch-sub-train': 'Trem do hype dinâmico que rastreia sequências rápidas de novos inscritos no canal.',
  'twitch-word-cloud': 'Nuvem de palavras dinâmicas que ressalta os tópicos mais comentados e repetidos do chat.',
  'twitch-emote-shower': 'Chuva de emotes flutuantes na tela acionada sempre que emotes são enviados no chat.',
  'twitch-uptime': 'Cronômetro preciso de tempo decorrido desde o início da transmissão.',
  'twitch-commands-list': 'Quadro informativo contendo a lista dos comandos de chat ativos para o público.',
  'twitch-milestones': 'Lista de marcos e conquistas completadas pela comunidade durante a transmissão.',
  'twitch-rules': 'Exibição animada das diretrizes e regras de comportamento configuradas para o canal.',
  'twitch-schedule': 'Agenda de transmissões contendo os dias, horários e tipos de lives da semana.',
  'twitch-schedule-ticker': 'Letreiro rotativo para avisos importantes, notícias e promoções do canal.',
  'twitch-moderator-feed': 'Histórico em tempo real de ações e logs executados pela moderação do canal.',
};

export default function WidgetsSection() {
  const { connections } = useStreaming();
  
  const twitchConn = connections?.Twitch || {};
  const isTwitchConnected = twitchConn.status === 'connected';

  return (
    <div className="space-y-6 animate-editor-fade-in">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-white">Widgets</h2>
          <p className="text-sm text-slate-400">Gerencie e visualize as widgets disponíveis para suas transmissões em tempo real</p>
        </div>
        
        {/* Status global da conexão Twitch */}
        <div className={`flex items-center gap-2.5 px-3.5 py-2 rounded-xl border text-xs font-mono font-medium backdrop-blur-md transition-all ${
          isTwitchConnected 
            ? 'bg-emerald-950/20 border-emerald-500/20 text-emerald-300' 
            : 'bg-rose-950/10 border-rose-500/10 text-rose-300'
        }`}>
          <span className={`h-2.5 w-2.5 rounded-full shrink-0 ${
            isTwitchConnected ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
          }`} />
          <span>
            Twitch: {isTwitchConnected ? 'CONECTADO (Mecanismo Ativo)' : 'DESCONECTADO (Aguardando Conexão)'}
          </span>
        </div>
      </header>

      {/* Alerta caso esteja desconectado */}
      {!isTwitchConnected && (
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 rounded-xl border border-rose-500/20 bg-rose-950/15 text-rose-200 text-xs">
          <div className="flex items-start sm:items-center gap-3">
            <AlertCircle className="h-4.5 w-4.5 text-rose-400 shrink-0 mt-0.5 sm:mt-0" />
            <span>
              Para que as widgets operem em modo <b className="text-white">FUNCIONAL</b> com eventos em tempo real, vincule e ative seu canal na seção de Conexões.
            </span>
          </div>
          <button 
            onClick={() => {
              // Navega simulando o clique em config
              const btn = document.querySelector('[data-section="config"]');
              if (btn) {
                btn.click();
              } else {
                window.location.hash = '#config';
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-medium transition-all shrink-0 active:scale-95 shadow-md"
          >
            <span>Ir para Conexões</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* Grid de Widgets */}
      <div className="grid gap-6 md:grid-cols-2">
        {TWITCH_WIDGETS_CATALOG.map(widget => {
          const WidgetComponent = widget.component;
          
          return (
            <div 
              key={widget.id}
              className="flex flex-col rounded-2xl border border-white/10 bg-slate-900/40 hover:bg-slate-900/60 transition-all overflow-hidden"
            >
              {/* Card Header */}
              <div className="p-4 border-b border-white/10 flex items-center justify-between bg-black/20 shrink-0">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-mono tracking-wider uppercase font-extrabold text-purple-400 bg-purple-950/35 border border-purple-500/20 px-2 py-0.5 rounded">
                      {widget.category === 'manual' ? 'Manual / Player' : MULTIPLATFORM_WIDGET_IDS.has(widget.id) ? 'Multiplataforma' : widget.category === 'youtube' ? 'YouTube' : 'Twitch'}
                    </span>
                    <span className="text-[10px] font-mono text-slate-500">
                      ID: {widget.id}
                    </span>
                  </div>
                  <h3 className="font-bold text-white text-sm truncate">{widget.name}</h3>
                </div>

                {/* Status Badge */}
                <div className="shrink-0">
                  {(widget.category === 'manual' || (widget.category === 'youtube' ? connections?.YouTube?.status === 'connected' : isTwitchConnected)) ? (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono uppercase font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 animate-pulse">
                      <Activity className="h-3 w-3" />
                      {widget.category === 'manual' ? 'Disponível' : 'Funcional'}
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono uppercase font-bold bg-rose-500/10 text-rose-400 border border-rose-500/25">
                      <AlertCircle className="h-3 w-3" />
                      Não Funcional
                    </span>
                  )}
                </div>
              </div>

              {/* Card Body & Live Preview */}
              <div className="p-4 flex-1 flex flex-col space-y-4">
                <p className="text-xs text-slate-400 leading-relaxed min-h-[32px]">
                  {WIDGET_DESCRIPTIONS[widget.id] || 'Widget de transmissão integrado em tempo real para enriquecer seu layout.'}
                </p>

                {/* Preview Container */}
                <div className="relative h-48 rounded-xl overflow-hidden border border-white/5 bg-slate-950/60 p-2 flex flex-col justify-end">
                  <div className="absolute top-2 left-2 z-10 select-none">
                    <span className="text-[9px] font-mono uppercase tracking-wider font-semibold text-slate-500 bg-black/40 px-1.5 py-0.5 rounded border border-white/5">
                      Visualização em Tempo Real
                    </span>
                  </div>
                  
                  {/* Mounted Widget */}
                  <div className="w-full h-full pt-6">
                    <WidgetComponent config={widget.defaultConfig} />
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
