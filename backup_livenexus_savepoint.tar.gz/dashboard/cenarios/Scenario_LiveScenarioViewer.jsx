import React, { useState, useEffect, useRef } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import WidgetElementRenderer from './editor/Scenario_WidgetElementRenderer';
import { matchesSubscenarioShortcut, broadcastScenarioChange, formatKeyFromEvent } from './Scenario_shortcutHelper';
import { useNewUserDataCentral } from '@dashboard/configuracao/DataCentral_NewUserDataCentral';
import { createRtcConsumer } from '@dashboard/conexao/rtcConsumer';

export default function LiveScenarioViewer() {
  const { userId, scenarioBranch } = useNewUserDataCentral();
  const { scenarioId } = useParams();
  const [searchParams] = useSearchParams();
  const sid = String(scenarioId || '');

  // Extract runtimeId from query parameter or default for receiver links
  const urlSearchParams = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : null;
  const isReceiverPath = typeof window !== 'undefined' && window.location.pathname.includes('/receiver/');
  const effectiveRuntimeId = searchParams.get('runtimeId') || 
    urlSearchParams?.get('runtimeId') || 
    (isReceiverPath ? '1222452' : null);

  const [cenario, setCenario] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const cenarioRef = useRef(null);
  cenarioRef.current = cenario;

  const [activeSubId, setActiveSubId] = useState(() => {
    if (typeof window !== 'undefined' && sid) {
      try {
        const stored = window.localStorage.getItem(`scenario_active_sub_${sid}`);
        if (stored) {
          const parsed = JSON.parse(stored);
          if (parsed.subscenarioId) return parsed.subscenarioId;
        }
      } catch {
        // ignore
      }
    }
    return null;
  });

  const activeSubIdRef = useRef(activeSubId);
  activeSubIdRef.current = activeSubId;

  const lastLocalSwitchTimeRef = useRef(0);

  const [windowSize, setWindowSize] = useState({
    width: typeof window !== 'undefined' ? window.innerWidth : 1920,
    height: typeof window !== 'undefined' ? window.innerHeight : 1080,
  });

  const containerRef = useRef(null);

  useEffect(() => {
    try {
      containerRef.current?.focus();
    } catch {
      // ignore
    }
  }, []);

  useEffect(() => {
    // Force both HTML and Body backgrounds to be fully transparent for OBS overlays
    const originalHtmlBg = document.documentElement.style.backgroundColor;
    const originalBodyBgColor = document.body.style.backgroundColor;
    const originalBodyBgImage = document.body.style.backgroundImage;

    document.documentElement.style.backgroundColor = 'transparent';
    document.body.style.backgroundColor = 'transparent';
    document.body.style.backgroundImage = 'none';

    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener('resize', handleResize);
    return () => {
      document.documentElement.style.backgroundColor = originalHtmlBg;
      document.body.style.backgroundColor = originalBodyBgColor;
      document.body.style.backgroundImage = originalBodyBgImage;
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // 1. WebRTC Consumer Real-Time Connection
  useEffect(() => {
    if (!effectiveRuntimeId) return;

    console.log('[LiveScenarioViewer] Conectando RTC Consumer com runtimeId:', effectiveRuntimeId);
    let consumer = null;

    try {
      consumer = createRtcConsumer({
        runtimeId: effectiveRuntimeId,
        onStateChange: (rtcState) => {
          if (!rtcState) return;

          // Snapshot or Scene Data from Publisher
          if (rtcState.sceneData) {
            setCenario(rtcState.sceneData);
            if (rtcState.sceneData.activeSubcenarioId) {
              setActiveSubId(rtcState.sceneData.activeSubcenarioId);
            }
          } else if (rtcState.scenesMap && sid && rtcState.scenesMap[sid]) {
            const sc = rtcState.scenesMap[sid];
            setCenario(sc);
            if (sc.activeSubcenarioId) {
              setActiveSubId(sc.activeSubcenarioId);
            }
          }

          // Live Event / Subscenario Switch via WebRTC
          if (rtcState.bridgeState?.lastEvent) {
            const ev = rtcState.bridgeState.lastEvent;
            if (ev.type === 'SWITCH_SUBSCENARIO' && ev.payload?.subscenarioId) {
              lastLocalSwitchTimeRef.current = Date.now();
              setActiveSubId(ev.payload.subscenarioId);
            }
          }
        },
      });
    } catch (err) {
      console.warn('[LiveScenarioViewer] Erro ao iniciar RTC Consumer:', err);
    }

    return () => {
      if (consumer) {
        try { consumer.stop(); } catch {}
      }
    };
  }, [effectiveRuntimeId, sid]);

  // 2. Cross-tab, Cross-window, OBS Studio BroadcastChannel & storage synchronization
  useEffect(() => {
    if (!sid || typeof window === 'undefined') return;

    let channel = null;
    try {
      if ('BroadcastChannel' in window) {
        channel = new BroadcastChannel(`scenario_channel_${sid}`);
        channel.onmessage = (event) => {
          if (event.data?.type === 'SWITCH_SUBSCENARIO' && event.data.subscenarioId) {
            lastLocalSwitchTimeRef.current = Date.now();
            setActiveSubId(event.data.subscenarioId);
          }
        };
      }
    } catch (err) {
      console.error('BroadcastChannel error:', err);
    }

    const handleStorage = (e) => {
      if (e.key === `scenario_active_sub_${sid}` && e.newValue) {
        try {
          const parsed = JSON.parse(e.newValue);
          if (parsed.subscenarioId) {
            lastLocalSwitchTimeRef.current = Date.now();
            setActiveSubId(parsed.subscenarioId);
          }
        } catch {
          // ignore
        }
      }
    };

    window.addEventListener('storage', handleStorage);

    return () => {
      if (channel) channel.close();
      window.removeEventListener('storage', handleStorage);
    };
  }, [sid]);

  // 3. Fetch scenario data (supports public unauthenticated fetching for receiver/OBS)
  useEffect(() => {
    if (!sid) return;

    const fetchPublicScenario = () => {
      fetch(`/api/cenarios?scenarioId=${encodeURIComponent(sid)}`)
        .then((res) => res.json())
        .then((data) => {
          if (data?.ok && data.cenario) {
            setCenario(data.cenario);
            setError(null);
            if (Date.now() - lastLocalSwitchTimeRef.current > 3000) {
              if (data.cenario.activeSubcenarioId) {
                setActiveSubId(data.cenario.activeSubcenarioId);
              } else if (!activeSubIdRef.current) {
                setActiveSubId('default');
              }
            } else if (!activeSubIdRef.current) {
              setActiveSubId(data.cenario.activeSubcenarioId || 'default');
            }
          } else {
            setError('Cenário não encontrado.');
          }
          setLoading(false);
        })
        .catch((err) => {
          console.error('Erro ao buscar cenário público:', err);
          setError('Erro de conexão ao buscar cenário.');
          setLoading(false);
        });
    };

    const fetchScenario = () => {
      if (userId && scenarioBranch) {
        scenarioBranch('GET', { id: sid })
          .then((scenario) => {
            if (scenario) {
              setCenario(scenario);
              setError(null);
              if (Date.now() - lastLocalSwitchTimeRef.current > 3000) {
                if (scenario.activeSubcenarioId) {
                  setActiveSubId(scenario.activeSubcenarioId);
                } else if (!activeSubIdRef.current) {
                  setActiveSubId('default');
                }
              } else if (!activeSubIdRef.current) {
                setActiveSubId(scenario.activeSubcenarioId || 'default');
              }
            } else {
              fetchPublicScenario();
            }
            setLoading(false);
          })
          .catch(() => {
            fetchPublicScenario();
          });
      } else {
        fetchPublicScenario();
      }
    };

    fetchScenario();
    const interval = setInterval(fetchScenario, 1000);

    return () => clearInterval(interval);
  }, [sid, userId, scenarioBranch]);

  // 3. Robust Permanent Keyboard Shortcut Listener for OBS Studio & Prism Live Overlays
  useEffect(() => {
    if (!sid || typeof window === 'undefined') return;

    const heldKeys = new Set();

    const handleKeyDown = (e) => {
      // Ignore if user is typing in a form input or editable area
      if (document.activeElement && (
          document.activeElement.tagName === 'INPUT' || 
          document.activeElement.tagName === 'TEXTAREA' || 
          document.activeElement.isContentEditable)) {
        return;
      }

      const formatted = formatKeyFromEvent(e);
      if (formatted) {
        heldKeys.add(formatted.toUpperCase());
      }
      if (e.key === 'Shift') heldKeys.add('SHIFT');
      if (e.key === 'Control' || e.key === 'Ctrl') heldKeys.add('CTRL');
      if (e.key === 'Alt') heldKeys.add('ALT');
      if (e.key === 'Meta' || e.key === 'OS') heldKeys.add('WIN');

      const currentCenario = cenarioRef.current;
      if (!currentCenario || !currentCenario.subcenarios || currentCenario.subcenarios.length === 0) {
        return;
      }

      const matchedSub = currentCenario.subcenarios.find((s) => matchesSubscenarioShortcut(e, s, heldKeys));
      if (matchedSub) {
        e.preventDefault();
        e.stopPropagation();

        lastLocalSwitchTimeRef.current = Date.now();
        setActiveSubId(matchedSub.id);

        // Notify server and sync to localStorage + BroadcastChannel
        scenarioBranch('POST', { id: sid, payload: { activeSubcenarioId: matchedSub.id } })
          .catch((err) => console.error('Erro ao atualizar subcenário ativo no servidor:', err));

        broadcastScenarioChange(sid, matchedSub.id);
      }
    };

    const handleKeyUp = (e) => {
      const formatted = formatKeyFromEvent(e);
      if (formatted) {
        heldKeys.delete(formatted.toUpperCase());
      }
      if (e.key === 'Shift') heldKeys.delete('SHIFT');
      if (e.key === 'Control' || e.key === 'Ctrl') heldKeys.delete('CTRL');
      if (e.key === 'Alt') heldKeys.delete('ALT');
      if (e.key === 'Meta' || e.key === 'OS') heldKeys.delete('WIN');
    };

    const handleBlur = () => {
      heldKeys.clear();
    };

    window.addEventListener('keydown', handleKeyDown, true);
    window.addEventListener('keyup', handleKeyUp, true);
    window.addEventListener('blur', handleBlur);
    document.addEventListener('keydown', handleKeyDown, true);
    document.addEventListener('keyup', handleKeyUp, true);

    return () => {
      window.removeEventListener('keydown', handleKeyDown, true);
      window.removeEventListener('keyup', handleKeyUp, true);
      window.removeEventListener('blur', handleBlur);
      document.removeEventListener('keydown', handleKeyDown, true);
      document.removeEventListener('keyup', handleKeyUp, true);
    };
  }, [sid]);

  if (loading) {
    return (
      <div className="fixed inset-0 bg-transparent flex items-center justify-center text-slate-400 font-mono text-sm">
        Carregando cenário...
      </div>
    );
  }

  if (error || !cenario) {
    return (
      <div className="fixed inset-0 bg-[#020617] flex items-center justify-center text-rose-400 font-mono text-sm p-4 text-center">
        {error || 'Cenário não disponível.'}
      </div>
    );
  }

  const activeSub = cenario.subcenarios?.find((s) => s.id === activeSubId) || 
                    cenario.subcenarios?.[0] || {
    instances: cenario.instances || [],
    background: cenario.background || { type: 'transparent' }
  };

  const getBackgroundStyle = () => {
    const bg = activeSub.background || { type: 'transparent' };
    const style = {};

    if (bg.type === 'transparent') {
      style.backgroundColor = 'transparent';
    } else if (bg.type === 'solid') {
      style.backgroundColor = bg.color || '#020617';
    } else if (bg.type === 'gradient') {
      style.backgroundImage = bg.gradient || 'linear-gradient(135deg, #1e1b4b 0%, #311042 100%)';
    } else if (bg.type === 'image' && bg.image) {
      style.backgroundImage = `url(${bg.image})`;
      style.backgroundSize = 'cover';
      style.backgroundPosition = 'center';
      style.backgroundRepeat = 'no-repeat';
    }

    const filters = [];
    if (bg.blur > 0) filters.push(`blur(${bg.blur}px)`);
    if (bg.brightness !== undefined && bg.brightness !== 100) filters.push(`brightness(${bg.brightness}%)`);
    if (bg.contrast !== undefined && bg.contrast !== 100) filters.push(`contrast(${bg.contrast}%)`);
    if (bg.saturate !== undefined && bg.saturate !== 100) filters.push(`saturate(${bg.saturate}%)`);

    if (filters.length > 0) {
      style.filter = filters.join(' ');
    }

    return style;
  };

  const logicalW = cenario.visualizerSize?.width || 1920;
  const logicalH = cenario.visualizerSize?.height || 1080;
  const bgStyle = getBackgroundStyle();

  // Dynamic scale: scale down proportionally when viewport is smaller than 1080p,
  // but cap at 1.0 so when the viewport is larger, elements retain their exact logical scale/pixels.
  const scale = Math.min(1.0, windowSize.width / logicalW, windowSize.height / logicalH);

  return (
    <div
      ref={containerRef}
      tabIndex={0}
      onClick={() => {
        try {
          containerRef.current?.focus();
        } catch {
          // ignore
        }
      }}
      className="fixed inset-0 w-screen h-screen flex items-center justify-center overflow-hidden bg-transparent outline-none focus:outline-none"
    >
      {/* 1920x1080 logical canvas centered and scaled */}
      <div
        style={{
          width: `${logicalW}px`,
          height: `${logicalH}px`,
          transform: `scale(${scale})`,
          transformOrigin: 'center center',
          position: 'relative',
          overflow: 'hidden',
          ...bgStyle,
          opacity: (activeSub.background?.opacity !== undefined ? activeSub.background.opacity : 100) / 100,
        }}
        className="shrink-0"
      >
        {activeSub.instances && activeSub.instances
          .filter((inst) => inst.visible !== false)
          .sort((a, b) => (a.zIndex || 0) - (b.zIndex || 0))
          .map((inst) => (
            <div
              key={inst.id}
              style={{
                position: 'absolute',
                left: `${inst.x}px`,
                top: `${inst.y}px`,
                width: inst.width ? `${inst.width}px` : '280px',
                height: inst.height ? `${inst.height}px` : 'auto',
                zIndex: inst.zIndex || 1,
                transform: `
                  ${inst.config?.rotation ? `rotate(${inst.config.rotation}deg)` : ''} 
                  ${inst.config?.flipH ? 'scaleX(-1)' : ''} 
                  ${inst.config?.flipV ? 'scaleY(-1)' : ''}
                `.trim() || undefined,
              }}
              className={inst.id?.includes('react') ? 'pointer-events-auto' : 'pointer-events-none'}
            >
              <div className="w-full h-full overflow-hidden flex items-center justify-start p-0">
                <WidgetElementRenderer
                  widgetId={inst.widgetId}
                  elementKey={inst.elementKey}
                  isFullWidget={inst.isFullWidget}
                  config={inst.config}
                  isEditing={false}
                  instanceId={inst.id}
                  instanceName={inst.name}
                />
              </div>
            </div>
          ))}
      </div>
    </div>
  );
}
