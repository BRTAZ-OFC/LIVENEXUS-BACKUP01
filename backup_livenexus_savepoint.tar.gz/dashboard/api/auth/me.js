import {
  SESSION_COOKIE,
  getCookie,
  resolveSessionId,
  getSession,
  upsertUserData,
  updateUserChannels,
  getUserById,
  publicUser,
  jsonResponse,
  errorResponse,
  handleDevPreflight
} from './_lib.js';

export async function onRequestOptions(context) {
  const { request, env } = context;
  const preflightRes = handleDevPreflight(request, env);
  if (preflightRes) return preflightRes;
  return new Response(null, { status: 204 });
}

export async function onRequestGet(context) {
  const { request, env } = context;
  if (!env.DB) return errorResponse('Database not configured', 500, request, env);

  const sessionId = resolveSessionId(request, env);
  if (!sessionId) return errorResponse('Not authenticated', 401, request, env);

  const session = await getSession(env, sessionId);
  if (!session) return errorResponse('Not authenticated', 401, request, env);

  return jsonResponse(publicUser(session), 200, {}, request, env);
}

export async function onRequestPatch(context) {
  const { request, env } = context;
  if (!env.DB) return errorResponse('Database not configured', 500, request, env);

  const sessionId = resolveSessionId(request, env);
  if (!sessionId) return errorResponse('Not authenticated', 401, request, env);

  const session = await getSession(env, sessionId);
  if (!session) return errorResponse('Not authenticated', 401, request, env);

  let body;
  try { body = await request.json(); } catch { return errorResponse('Invalid request body', 400); }

  if (body.channels !== undefined) {
    await updateUserChannels(env, session.id, body.channels);
  }

  const userDataUpdates = {};
  let rawData = null;
  if (body.data !== undefined) {
    try {
      rawData = typeof body.data === 'string' ? JSON.parse(body.data) : body.data;
    } catch {
      rawData = {};
    }
  }

  if (body.display_name !== undefined) userDataUpdates.display_name = body.display_name;
  else if (rawData && rawData.display_name !== undefined) userDataUpdates.display_name = rawData.display_name;

  if (body.gallery !== undefined) userDataUpdates.gallery = body.gallery;
  else if (rawData && rawData.gallery !== undefined) userDataUpdates.gallery = rawData.gallery;

  if (body.rtc_registry !== undefined) userDataUpdates.rtc_registry = body.rtc_registry;
  else if (body.rtcRegistry !== undefined) userDataUpdates.rtc_registry = body.rtcRegistry;
  else if (rawData && rawData.rtc_registry !== undefined) userDataUpdates.rtc_registry = rawData.rtc_registry;
  else if (rawData && rawData.rtcRegistry !== undefined) userDataUpdates.rtc_registry = rawData.rtcRegistry;

  if (body.user_library !== undefined) userDataUpdates.user_library = body.user_library;
  else if (body.userLibrary !== undefined) userDataUpdates.user_library = body.userLibrary;
  else if (rawData && rawData.user_library !== undefined) userDataUpdates.user_library = rawData.user_library;
  else if (rawData && rawData.userLibrary !== undefined) userDataUpdates.user_library = rawData.userLibrary;

  if (Object.keys(userDataUpdates).length > 0) {
    await upsertUserData(env, session.id, userDataUpdates);
  }

  const user = await getUserById(env, session.id);
  return jsonResponse(publicUser(user), 200, {}, request, env);
}