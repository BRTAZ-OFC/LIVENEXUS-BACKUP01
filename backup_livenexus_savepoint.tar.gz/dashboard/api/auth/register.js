import {
  getUserByEmail,
  hashPassword,
  generateSalt,
  generateSessionId,
  createSession,
  setSessionCookie,
  getUserById,
  publicUser,
  jsonResponse,
  errorResponse,
  handleDevPreflight
} from './_lib.js';

export async function onRequestOptions(context) {
  const { request, env } = context;
  const preflightRes = handleDevPreflight(request, env);
  if (preflightRes) return preflightRes;
  return new Response(null, { status: 204 });
}

export async function onRequestPost(context) {
  const { request, env } = context;
  if (!env.DB) return errorResponse('Database not configured', 500, request, env);

  let body;
  try { body = await request.json(); } catch { return errorResponse('Invalid request body', 400, request, env); }

  const email = (body.email || '').toLowerCase().trim();
  const password = body.password || '';
  if (!email || !password) return errorResponse('Email and password required', 400, request, env);
  if (password.length < 6) return errorResponse('Password must be at least 6 characters', 400, request, env);

  const existing = await getUserByEmail(env, email);
  if (existing) return errorResponse('Email already registered', 409, request, env);

  const salt = generateSalt();
  const hash = await hashPassword(password, salt);
  const userId = crypto.randomUUID();
  const now = new Date().toISOString();

  await env.DB.prepare(
    'INSERT INTO users (id, email, full_name, password_hash, password_salt, role, channels) VALUES (?, ?, ?, ?, ?, ?, ?)'
  ).bind(userId, email, null, hash, salt, 'user', '{}').run();

  await env.DB.prepare(
    `INSERT INTO user_data (user_id, display_name, gallery, user_library, rtc_registry, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    userId,
    null,
    '[]',
    '{"songs":[],"albums":[],"artists":[],"playlists":[]}',
    '{"scenes":{},"overlays":{}}',
    now,
    now
  ).run();

  const sessionId = generateSessionId();
  await createSession(env, sessionId, userId);

  const user = await getUserById(env, userId);
  const secure = request.url.startsWith('https://');

  const isDev = env.DEV_MODE === 'true' || env.DEV_MODE === true;
  const responseData = publicUser(user);
  if (isDev) {
    responseData.token = sessionId;
    responseData.user = publicUser(user);
  }

  return jsonResponse(responseData, 201, {
    'Set-Cookie': setSessionCookie(sessionId, secure),
  }, request, env);
}