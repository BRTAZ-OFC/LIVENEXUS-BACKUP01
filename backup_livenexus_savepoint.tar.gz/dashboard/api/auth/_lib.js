// Shared utilities for auth Pages Functions (Cloudflare Pages + D1)
// PBKDF2 password hashing via Web Crypto, session management via D1.
//
// NOTE (lab): In the official GitHub repo this file lives at functions/api/auth/_lib.js
// and is served by Cloudflare Pages Functions with a D1 binding (env.DB).
// In this Base44 lab the functions/ path is reserved by the Base44 backend bundler,
// so the Cloudflare Pages Functions are mirrored under cloudflare-pages/functions/
// to preserve the original code without converting to Base44 Functions.
// The D1 binding (env.DB) is NOT available in the Base44 preview environment.

export const SESSION_COOKIE = 'lnx_session';
const SESSION_DURATION_DAYS = 7;
const PBKDF2_ITERATIONS = 100000;

// --- Password hashing (PBKDF2 via Web Crypto) ---

export async function hashPassword(password, salt) {
  const enc = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']
  );
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: enc.encode(salt), iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    keyMaterial, 256
  );
  return bufToBase64(bits);
}

export async function verifyPassword(password, salt, expectedHash) {
  const hash = await hashPassword(password, salt);
  return timingSafeEqual(hash, expectedHash);
}

export function generateSalt() {
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return bufToBase64(arr.buffer);
}

// --- Session management ---

export function generateSessionId() {
  const arr = new Uint8Array(32);
  crypto.getRandomValues(arr);
  return bufToHex(arr.buffer);
}

export function getCookie(request, name) {
  const cookieHeader = request.headers.get('Cookie') || '';
  const match = cookieHeader.match(new RegExp('(?:^|;\\s*)' + name + '=([^;]+)'));
  return match ? match[1].trim() : null;
}

export function setSessionCookie(sessionId, secure) {
  const flags = [
    `${SESSION_COOKIE}=${sessionId}`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    `Max-Age=${SESSION_DURATION_DAYS * 86400}`,
  ];
  if (secure) flags.push('Secure');
  return flags.join('; ');
}

export function clearSessionCookie(secure) {
  const flags = [
    `${SESSION_COOKIE}=`,
    'Path=/',
    'HttpOnly',
    'SameSite=Lax',
    'Max-Age=0',
  ];
  if (secure) flags.push('Secure');
  return flags.join('; ');
}

// --- D1 queries ---

export async function getUserByEmail(env, email) {
  return env.DB.prepare(`
    SELECT u.*,
           ud.display_name,
           ud.gallery,
           ud.user_library,
           ud.rtc_registry,
           ud.created_at as ud_created_at,
           ud.updated_at as ud_updated_at
    FROM users u
    LEFT JOIN user_data ud ON u.id = ud.user_id
    WHERE u.email = ?
  `).bind(email).first();
}

export async function getUserById(env, userId) {
  return env.DB.prepare(`
    SELECT u.*,
           ud.display_name,
           ud.gallery,
           ud.user_library,
           ud.rtc_registry,
           ud.created_at as ud_created_at,
           ud.updated_at as ud_updated_at
    FROM users u
    LEFT JOIN user_data ud ON u.id = ud.user_id
    WHERE u.id = ?
  `).bind(userId).first();
}

export async function createSession(env, sessionId, userId) {
  const expiresAt = new Date(Date.now() + SESSION_DURATION_DAYS * 86400000).toISOString();
  await env.DB.prepare('INSERT INTO sessions (id, user_id, expires_at) VALUES (?, ?, ?)')
    .bind(sessionId, userId, expiresAt).run();
}

export async function getSession(env, sessionId) {
  return env.DB.prepare(`
    SELECT s.id as session_id,
           u.*,
           ud.display_name,
           ud.gallery,
           ud.user_library,
           ud.rtc_registry,
           ud.created_at as ud_created_at,
           ud.updated_at as ud_updated_at
    FROM sessions s
    JOIN users u ON s.user_id = u.id
    LEFT JOIN user_data ud ON u.id = ud.user_id
    WHERE s.id = ? AND s.expires_at > datetime('now')
  `).bind(sessionId).first();
}

export async function deleteSession(env, sessionId) {
  await env.DB.prepare('DELETE FROM sessions WHERE id = ?').bind(sessionId).run();
}

export async function updateUserChannels(env, userId, channels) {
  await env.DB.prepare("UPDATE users SET channels = ?, updated_at = datetime('now') WHERE id = ?")
    .bind(JSON.stringify(channels), userId).run();
}

export async function upsertUserData(env, userId, updates) {
  if (!userId || !updates || typeof updates !== 'object') return;
  const now = new Date().toISOString();

  const existing = await env.DB.prepare('SELECT user_id FROM user_data WHERE user_id = ?')
    .bind(userId)
    .first();

  if (!existing) {
    const initialDisplayName = updates.display_name !== undefined ? updates.display_name : null;
    const initialGallery = updates.gallery !== undefined
      ? (typeof updates.gallery === 'string' ? updates.gallery : JSON.stringify(updates.gallery))
      : '[]';
    const initialUserLibrary = updates.user_library !== undefined
      ? (typeof updates.user_library === 'string' ? updates.user_library : JSON.stringify(updates.user_library))
      : '{"songs":[],"albums":[],"artists":[],"playlists":[]}';
    const initialRtcRegistry = updates.rtc_registry !== undefined
      ? (typeof updates.rtc_registry === 'string' ? updates.rtc_registry : JSON.stringify(updates.rtc_registry))
      : '{"scenes":{},"overlays":{}}';

    await env.DB.prepare(`
      INSERT INTO user_data (user_id, display_name, gallery, user_library, rtc_registry, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(userId, initialDisplayName, initialGallery, initialUserLibrary, initialRtcRegistry, now, now).run();
    return;
  }

  const fields = [];
  const values = [];

  if (updates.display_name !== undefined) {
    fields.push('display_name = ?');
    values.push(updates.display_name);
  }
  if (updates.gallery !== undefined) {
    fields.push('gallery = ?');
    values.push(typeof updates.gallery === 'string' ? updates.gallery : JSON.stringify(updates.gallery));
  }
  if (updates.user_library !== undefined) {
    fields.push('user_library = ?');
    values.push(typeof updates.user_library === 'string' ? updates.user_library : JSON.stringify(updates.user_library));
  }
  if (updates.rtc_registry !== undefined) {
    fields.push('rtc_registry = ?');
    values.push(typeof updates.rtc_registry === 'string' ? updates.rtc_registry : JSON.stringify(updates.rtc_registry));
  }

  if (fields.length > 0) {
    fields.push('updated_at = ?');
    values.push(now);
    values.push(userId);

    const query = `UPDATE user_data SET ${fields.join(', ')} WHERE user_id = ?`;
    await env.DB.prepare(query).bind(...values).run();
  }
}

// --- Response helpers ---

export function publicUser(row) {
  if (!row) return null;
  let channels = {};
  try {
    channels = typeof row.channels === 'string' ? JSON.parse(row.channels || '{}') : (row.channels || {});
  } catch {}

  let legacyData = {};
  try {
    legacyData = typeof row.data === 'string' ? JSON.parse(row.data || '{}') : (row.data || {});
  } catch {}

  const displayName = row.display_name !== undefined && row.display_name !== null
    ? row.display_name
    : (legacyData.display_name || row.full_name || row.email);

  let gallery = [];
  if (row.gallery !== undefined && row.gallery !== null) {
    try {
      gallery = typeof row.gallery === 'string' ? JSON.parse(row.gallery) : row.gallery;
    } catch {
      gallery = [];
    }
  } else if (Array.isArray(legacyData.gallery)) {
    gallery = legacyData.gallery;
  }

  let rtcRegistry = { scenes: {}, overlays: {}, user_sessions: {} };
  if (row.rtc_registry !== undefined && row.rtc_registry !== null) {
    try {
      const parsed = typeof row.rtc_registry === 'string' ? JSON.parse(row.rtc_registry) : row.rtc_registry;
      if (parsed && typeof parsed === 'object') {
        rtcRegistry = {
          scenes: parsed.scenes || {},
          overlays: parsed.overlays || {},
          user_sessions: parsed.user_sessions || {},
        };
      }
    } catch {}
  } else if (legacyData.rtcRegistry && typeof legacyData.rtcRegistry === 'object') {
    rtcRegistry = legacyData.rtcRegistry;
  }

  let userLibrary = { songs: [], albums: [], artists: [], playlists: [] };
  if (row.user_library !== undefined && row.user_library !== null) {
    try {
      const parsed = typeof row.user_library === 'string' ? JSON.parse(row.user_library) : row.user_library;
      if (parsed && typeof parsed === 'object') {
        userLibrary = {
          songs: Array.isArray(parsed.songs) ? parsed.songs : [],
          albums: Array.isArray(parsed.albums) ? parsed.albums : [],
          artists: Array.isArray(parsed.artists) ? parsed.artists : [],
          playlists: Array.isArray(parsed.playlists) ? parsed.playlists : [],
        };
      }
    } catch {}
  } else if (legacyData.userLibrary && typeof legacyData.userLibrary === 'object') {
    userLibrary = legacyData.userLibrary;
  }

  const data = {
    ...legacyData,
    display_name: displayName,
    gallery,
    rtcRegistry,
    userLibrary,
  };

  return {
    id: row.id,
    email: row.email,
    full_name: displayName || row.full_name || row.email,
    role: row.role,
    channels,
    data,
  };
}

export function resolveSessionId(request, env) {
  const cookieSession = getCookie(request, 'lnx_session');
  if (cookieSession) {
    return cookieSession;
  }

  const isDev = env && (env.DEV_MODE === 'true' || env.DEV_MODE === true);
  if (isDev) {
    const authHeader = request.headers.get('Authorization') || '';
    if (authHeader.startsWith('Bearer ')) {
      return authHeader.substring(7).trim();
    }
  }

  return null;
}

export function isOriginAllowed(origin, env) {
  if (!origin) return false;
  const allowedStr = env.DEV_ALLOWED_ORIGINS || '';
  const allowedList = allowedStr.split(',').map(o => o.trim().toLowerCase());
  return allowedList.includes(origin.toLowerCase());
}

export function handleDevPreflight(request, env) {
  const isDev = env && (env.DEV_MODE === 'true' || env.DEV_MODE === true);
  if (isDev && request.method === 'OPTIONS') {
    const origin = request.headers.get('Origin');
    if (origin && isOriginAllowed(origin, env)) {
      const headers = {
        'Access-Control-Allow-Origin': origin,
        'Access-Control-Allow-Credentials': 'true',
        'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Max-Age': '86400'
      };
      return new Response(null, { status: 204, headers });
    }
  }
  return null;
}

export function jsonResponse(data, status, extraHeaders, request, env) {
  const headers = { 'Content-Type': 'application/json', ...(extraHeaders || {}) };
  if (request && env) {
    const isDev = env.DEV_MODE === 'true' || env.DEV_MODE === true;
    if (isDev) {
      const origin = request.headers.get('Origin');
      if (origin && isOriginAllowed(origin, env)) {
        headers['Access-Control-Allow-Origin'] = origin;
        headers['Access-Control-Allow-Credentials'] = 'true';
        headers['Access-Control-Allow-Methods'] = 'GET, POST, PATCH, PUT, DELETE, OPTIONS';
        headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization';
      }
    }
  }
  return new Response(JSON.stringify(data), {
    status: status || 200,
    headers,
  });
}

export function errorResponse(message, status, request, env) {
  return jsonResponse({ message }, status || 400, {}, request, env);
}

// --- Internal ---

function bufToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function bufToHex(buffer) {
  const bytes = new Uint8Array(buffer);
  return Array.from(bytes).map(function(b) { return b.toString(16).padStart(2, '0'); }).join('');
}

function timingSafeEqual(a, b) {
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return result === 0;
}
