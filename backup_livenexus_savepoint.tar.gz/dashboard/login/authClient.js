// authClient — cliente de autenticação nativo e portável do LiveNexus.
// Conecta-se diretamente aos endpoints da API do LiveNexus (/api/auth/...)
// e gerencia credenciais de sessão locais de forma limpa e desacoplada.
import { safeStorage } from './safeStorage';

const STORAGE_TOKEN_KEY = 'livenexus_access_token';
const STORAGE_USER_KEY = 'livenexus_current_user';

const API_BASE_URL = '';

export const authClient = {
  // Retorna o token atual armazenado
  getToken() {
    if (typeof window === 'undefined') return null;
    return safeStorage.getItem(STORAGE_TOKEN_KEY) || safeStorage.getItem('token');
  },

  // Define o token no storage
  setToken(token) {
    if (typeof window === 'undefined') return;
    if (token) {
      safeStorage.setItem(STORAGE_TOKEN_KEY, token);
      safeStorage.setItem('token', token);
    } else {
      safeStorage.removeItem(STORAGE_TOKEN_KEY);
      safeStorage.removeItem('token');
    }
  },

  // Retorna o cache local de dados do usuário (somente para leitura/exibição secundária)
  // NUNCA deve ser usado como prova ou autoridade de autenticação.
  getUserDataCache() {
    if (typeof window === 'undefined') return null;
    try {
      const cached = safeStorage.getItem(STORAGE_USER_KEY);
      return cached ? JSON.parse(cached) : null;
    } catch {
      return null;
    }
  },

  // Consulta os dados do usuário autenticado atual no backend.
  // O backend (/api/auth/me) é a ÚNICA autoridade para determinar sessão autenticada.
  async me() {
    // Suporte a Administrador Fake de Teste no ambiente local/preview do AI Studio
    if (this.getToken() === 'fake-admin-dev-token') {
      const cached = this.getUserDataCache();
      if (cached && cached.role === 'admin') {
        return cached;
      }
      const fakeAdmin = {
        id: 'usr_admin_test_001',
        email: 'admin@livenexus.local',
        display_name: 'Admin LiveNexus (Teste)',
        role: 'admin',
        created_at: new Date().toISOString()
      };
      if (typeof window !== 'undefined') {
        safeStorage.setItem(STORAGE_USER_KEY, JSON.stringify(fakeAdmin));
      }
      return fakeAdmin;
    }

    try {
      const res = await fetch(`${API_BASE_URL}/api/auth/me`, {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          ...(this.getToken() ? { Authorization: `Bearer ${this.getToken()}` } : {})
        }
      });

      if (res.ok) {
        const user = await res.json();
        if (typeof window !== 'undefined') {
          safeStorage.setItem(STORAGE_USER_KEY, JSON.stringify(user));
        }
        return user;
      }

      // Resposta não-2xx (401, etc.): invalida cache local e lança erro de autenticação
      if (typeof window !== 'undefined') {
        safeStorage.removeItem(STORAGE_USER_KEY);
        safeStorage.removeItem(STORAGE_TOKEN_KEY);
        safeStorage.removeItem('token');
      }

      const err = new Error('Authentication required');
      err.status = res.status;
      throw err;
    } catch (err) {
      // Falhas de rede ou status 401: NÃO usa cache local como credencial de autenticação
      if (typeof window !== 'undefined') {
        safeStorage.removeItem(STORAGE_USER_KEY);
      }
      if (err.status) throw err;
      const netErr = new Error(err.message || 'Authentication check failed');
      netErr.status = 401;
      throw netErr;
    }
  },

  // Login de Administrador Fake para testes em desenvolvimento
  loginAsFakeAdmin() {
    const fakeAdmin = {
      id: 'usr_admin_test_001',
      email: 'admin@livenexus.local',
      display_name: 'Admin LiveNexus (Teste)',
      role: 'admin',
      created_at: new Date().toISOString()
    };
    this.setToken('fake-admin-dev-token');
    if (typeof window !== 'undefined') {
      safeStorage.setItem(STORAGE_USER_KEY, JSON.stringify(fakeAdmin));
    }
    return { token: 'fake-admin-dev-token', user: fakeAdmin };
  },

  // Login por e-mail e senha
  async login({ email, password }) {
    const normalizedEmail = (email || '').toLowerCase().trim();
    if (normalizedEmail === 'admin@livenexus.local' || normalizedEmail === 'admin@teste.local') {
      return this.loginAsFakeAdmin();
    }

    const res = await fetch(`${API_BASE_URL}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email, password })
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.message || errorData.error || `Erro do servidor: ${res.status}`);
    }

    const data = await res.json().catch(() => ({}));
    if (data.token || data.access_token) {
      this.setToken(data.token || data.access_token);
    }
    if (data.user && typeof window !== 'undefined') {
      safeStorage.setItem(STORAGE_USER_KEY, JSON.stringify(data.user));
    }
    return data;
  },

  // Cadastro de nova conta
  async register({ email, password }) {
    const res = await fetch(`${API_BASE_URL}/api/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email, password })
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.message || 'Falha no cadastro');
    }

    const data = await res.json().catch(() => ({}));
    return data;
  },

  // Verificação de código OTP
  async verifyOtp({ email, otpCode }) {
    const res = await fetch(`${API_BASE_URL}/api/auth/verify-otp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email, otpCode })
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.message || 'Código de verificação inválido');
    }

    const data = await res.json().catch(() => ({}));
    if (data.token || data.access_token) {
      this.setToken(data.token || data.access_token);
    }
    if (data.user && typeof window !== 'undefined') {
      safeStorage.setItem(STORAGE_USER_KEY, JSON.stringify(data.user));
    }
    return data;
  },

  // Reenviar código OTP
  async resendOtp(email) {
    const res = await fetch(`${API_BASE_URL}/api/auth/resend-otp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email })
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.message || 'Falha ao reenviar o código');
    }

    return await res.json().catch(() => ({ success: true }));
  },

  // Solicitação de recuperação de senha
  async forgotPassword(email) {
    const res = await fetch(`${API_BASE_URL}/api/auth/forgot-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ email })
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.message || 'Falha na recuperação de senha');
    }

    return await res.json().catch(() => ({ success: true }));
  },

  // Redefinição de senha com token
  async resetPassword({ resetToken, newPassword }) {
    const res = await fetch(`${API_BASE_URL}/api/auth/reset-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
      body: JSON.stringify({ token: resetToken, newPassword })
    });

    if (!res.ok) {
      const errorData = await res.json().catch(() => ({}));
      throw new Error(errorData.message || 'Falha ao redefinir a senha');
    }

    return await res.json().catch(() => ({ success: true }));
  },

  // Login com provedor social (Google, etc)
  loginWithProvider(provider = 'google', returnTo = '/dashboard') {
    if (typeof window === 'undefined') return;
    const url = `${API_BASE_URL}/api/auth/${provider}?returnTo=${encodeURIComponent(returnTo)}`;
    window.location.href = url;
  },

  // Atualiza dados do usuário autenticado
  async updateMe(updates = {}) {
    try {
      const res = await fetch(`${API_BASE_URL}/api/auth/me`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          ...(this.getToken() ? { Authorization: `Bearer ${this.getToken()}` } : {})
        },
        credentials: 'include',
        body: JSON.stringify(updates)
      });

      if (res.ok) {
        const user = await res.json();
        if (typeof window !== 'undefined') {
          safeStorage.setItem(STORAGE_USER_KEY, JSON.stringify(user));
        }
        return user;
      }
    } catch {
      // Ignora falha remota e aplica localmente apenas se houver usuário em cache
    }

    if (typeof window !== 'undefined') {
      const currentJson = safeStorage.getItem(STORAGE_USER_KEY);
      if (currentJson) {
        const user = JSON.parse(currentJson);
        const updated = { ...user, ...updates };
        safeStorage.setItem(STORAGE_USER_KEY, JSON.stringify(updated));
        return updated;
      }
    }
    return updates;
  },

  // Encerra sessão do usuário: invalida credenciais remotas e remove caches locais
  async logout(redirectUrl = '/login') {
    try {
      await fetch(`${API_BASE_URL}/api/auth/logout`, {
        method: 'POST',
        credentials: 'include',
        headers: {
          ...(this.getToken() ? { Authorization: `Bearer ${this.getToken()}` } : {})
        }
      });
    } catch (e) {
      console.error('Logout error on server:', e);
    } finally {
      if (typeof window !== 'undefined') {
        safeStorage.removeItem(STORAGE_TOKEN_KEY);
        safeStorage.removeItem('token');
        safeStorage.removeItem(STORAGE_USER_KEY);
        if (redirectUrl) {
          window.location.href = redirectUrl;
        }
      }
    }
  }
};
