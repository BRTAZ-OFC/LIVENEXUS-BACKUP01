import React, { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { authClient } from "@dashboard/login/authClient";
import { Button } from "@dashboard/componentes/ui/button";
import { Input } from "@dashboard/componentes/ui/input";
import { Label } from "@dashboard/componentes/ui/label";
import { KeyRound, Lock, Loader2, CheckCircle2 } from "lucide-react";
import AuthLayout from "@dashboard/login/AuthLayout";

export default function ResetPassword() {
  const [searchParams] = useSearchParams();
  const resetToken = searchParams.get("token");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (newPassword !== confirmPassword) {
      setError("As senhas não coincidem");
      return;
    }

    if (!resetToken) {
      setError("Token de recuperação inválido ou ausente");
      return;
    }

    setLoading(true);
    try {
      await authClient.resetPassword({ resetToken, newPassword });
      setSuccess(true);
    } catch (err) {
      setError(err.message || "Falha ao redefinir a senha");
    } finally {
      setLoading(false);
    }
  };

  if (!resetToken && !success) {
    return (
      <AuthLayout
        icon={KeyRound}
        title="Link inválido"
        subtitle="O link de recuperação de senha é inválido ou expirou."
        footer={
          <Link to="/forgot-password" className="text-primary font-medium hover:underline">
            Solicitar novo link
          </Link>
        }
      >
        <div className="text-center">
          <Button
            variant="outline"
            className="w-full h-12 font-medium"
            onClick={() => navigate("/forgot-password")}
          >
            Solicitar novo link
          </Button>
        </div>
      </AuthLayout>
    );
  }

  if (success) {
    return (
      <AuthLayout
        icon={CheckCircle2}
        title="Senha redefinida!"
        subtitle="Sua senha foi alterada com sucesso. Você já pode fazer login."
        footer={
          <Link to="/login" className="text-primary font-medium hover:underline">
            Ir para o login
          </Link>
        }
      >
        <Button
          className="w-full h-12 font-medium"
          onClick={() => navigate("/login")}
        >
          Fazer login
        </Button>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      icon={KeyRound}
      title="Redefinir sua senha"
      subtitle="Digite sua nova senha abaixo"
      footer={
        <Link to="/login" className="text-primary font-medium hover:underline">
          Voltar para o login
        </Link>
      }
    >
      {error && (
        <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="newPassword">Nova senha</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="newPassword"
              type="password"
              autoComplete="new-password"
              autoFocus
              placeholder="Digite a nova senha"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="pl-10 h-12"
              required
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="confirmPassword">Confirmar nova senha</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="confirmPassword"
              type="password"
              autoComplete="new-password"
              placeholder="Confirme a nova senha"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="pl-10 h-12"
              required
            />
          </div>
        </div>
        <Button type="submit" className="w-full h-12 font-medium" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Redefinindo...
            </>
          ) : (
            "Redefinir senha"
          )}
        </Button>
      </form>
    </AuthLayout>
  );
}
