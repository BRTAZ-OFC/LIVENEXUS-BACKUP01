import React, { useState } from "react";
import { Link } from "react-router-dom";
import { authClient } from "@dashboard/login/authClient";
import { Button } from "@dashboard/componentes/ui/button";
import { Input } from "@dashboard/componentes/ui/input";
import { Label } from "@dashboard/componentes/ui/label";
import { LogIn, Mail, Lock, Loader2, ShieldCheck } from "lucide-react";
import AuthLayout from "@dashboard/login/AuthLayout";
import GoogleIcon from "@dashboard/componentes/GoogleIcon";
import { safeReturnTo } from "@dashboard/login/authReturnTo";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const returnTo = safeReturnTo();

  const handleTestAdmin = () => {
    setError("");
    setLoading(true);
    try {
      authClient.loginAsFakeAdmin();
      window.location.href = returnTo || "/dashboard";
    } catch (err) {
      setError(err.message || "Erro ao iniciar sessão de teste");
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await authClient.login({ email, password });
      window.location.href = returnTo;
    } catch (err) {
      setError(err.message || "E-mail ou senha inválidos");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = () => {
    authClient.loginWithProvider("google", returnTo);
  };

  return (
    <AuthLayout
      icon={LogIn}
      title="Bem-vindo de volta!"
      subtitle="Faça login para acessar sua conta"
      footer={
        <>
          Não tem conta?{" "}
          <Link
            to={"/register" + (returnTo !== "/dashboard" ? "?returnTo=" + encodeURIComponent(returnTo) : "")}
            className="text-primary font-medium hover:underline"
          >
            Criar conta
          </Link>
        </>
      }
    >
      <Button
        variant="outline"
        className="w-full h-12 text-sm font-medium mb-6"
        onClick={handleGoogle}
      >
        <GoogleIcon className="w-5 h-5 mr-2" />
        Continuar com Google
      </Button>

      <div className="relative mb-6">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-card px-3 text-muted-foreground">ou</span>
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">E-mail</Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="email"
              type="email"
              autoComplete="email"
              autoFocus
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-10 h-12"
              required
            />
          </div>
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="password">Senha</Label>
            <Link to="/forgot-password" className="text-xs text-primary hover:underline">
              Esqueceu sua senha?
            </Link>
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="password"
              type="password"
              autoComplete="current-password"
              placeholder="Digite sua senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="pl-10 h-12"
              required
            />
          </div>
        </div>
        <Button type="submit" className="w-full h-12 font-medium" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Entrando...
            </>
          ) : (
            "Entrar"
          )}
        </Button>
      </form>

      {/* Acesso Admin de Teste Temporário (Ambiente AI Studio) */}
      <div className="mt-6 pt-5 border-t border-violet-500/20">
        <div className="rounded-xl border border-violet-500/30 bg-violet-950/20 p-3.5 text-center space-y-2">
          <div className="flex items-center justify-center gap-1.5 text-xs font-semibold text-violet-300">
            <ShieldCheck className="w-4 h-4 text-violet-400" />
            <span>Ambiente de Teste (AI Studio)</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Acesso administrativo temporário pré-configurado sem dependência do backend Cloudflare.
          </p>
          <Button
            type="button"
            variant="secondary"
            onClick={handleTestAdmin}
            disabled={loading}
            className="w-full h-10 text-xs font-semibold bg-violet-600/20 hover:bg-violet-600/30 text-violet-200 border border-violet-500/40"
          >
            ⚡ Entrar como Administrador (Teste)
          </Button>
        </div>
      </div>
    </AuthLayout>
  );
}
