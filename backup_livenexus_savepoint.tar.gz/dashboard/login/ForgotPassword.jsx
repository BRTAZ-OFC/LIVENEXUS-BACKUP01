import React, { useState } from "react";
import { Link } from "react-router-dom";
import { authClient } from "@dashboard/login/authClient";
import { Button } from "@dashboard/componentes/ui/button";
import { Input } from "@dashboard/componentes/ui/input";
import { Label } from "@dashboard/componentes/ui/label";
import { KeyRound, Mail, Loader2, CheckCircle2 } from "lucide-react";
import AuthLayout from "@dashboard/login/AuthLayout";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await authClient.forgotPassword(email);
      setSubmitted(true);
    } catch (err) {
      setError(err.message || "Falha ao enviar solicitação");
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <AuthLayout
        icon={CheckCircle2}
        title="Verifique seu e-mail"
        subtitle="Se houver uma conta com este e-mail, enviamos instruções para redefinir sua senha."
        footer={
          <Link to="/login" className="text-primary font-medium hover:underline">
            Voltar para o login
          </Link>
        }
      >
        <div className="text-center">
          <p className="text-sm text-muted-foreground mb-6">
            Não recebeu o e-mail? Verifique sua caixa de spam ou tente novamente.
          </p>
          <Button
            variant="outline"
            className="w-full h-12 font-medium"
            onClick={() => setSubmitted(false)}
          >
            Tentar outro e-mail
          </Button>
        </div>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout
      icon={KeyRound}
      title="Esqueceu sua senha?"
      subtitle="Digite seu e-mail para receber as instruções de recuperação"
      footer={
        <Link to="/login" className="text-primary font-medium hover:underline">
          Voltar para o login
        </Link>
      }
    >
      {error && (
        <div className="mb-4 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">E-mail</Label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" aria-hidden="true" />
            <Input
              id="email"
              type="email"
              autoComplete="email"
              autoFocus
              placeholder="seu@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="pl-10 h-12"
              required
            />
          </div>
        </div>
        <Button type="submit" className="w-full h-12 font-medium" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Enviando...
            </>
          ) : (
            "Enviar instruções"
          )}
        </Button>
      </form>
    </AuthLayout>
  );
}
