// WebRTC Publisher Controller para Laboratório RTC Manual.
// Responsabilidade:
// 1. Iniciar RTCPeerConnection e RTCDataChannel para um runtimeId exclusivo.
// 2. Estabelecer conexão via sinalização isolada.
// 3. Obter dados da sessão em tempo real.
// 4. Enviar snapshot inicial COMPLETO e transmitir eventos live via RTCDataChannel exclusivamente.
// 5. Cleanup completo ao desconectar.

import { createRtcSignaling } from './rtcSignaling';
import { registerRtcRuntime, unregisterRtcRuntime } from './rtcRegistryService';

const RTC_CONFIG = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

export function createRtcPublisher({ contentInfo, onStatsChange, customRuntimeId = null }) {
  const runtimeId = customRuntimeId || `rt_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  const peers = new Map(); // consumerId -> { pc, dc, isMakingOffer }
  let signaling = null;
  let unsubBridge = null;
  let unsubScene = null;
  let isStopped = false;
  let eventsHooked = false;

  const stats = {
    runtimeId,
    contentInfo,
    activeConsumers: 0,
    peerState: 'new',
    iceState: 'new',
    channelState: 'idle',
    eventsSent: 0,
    bytesSent: 0,
    lastEventSent: null,
    recentEvents: [],
    connectedAt: null,
    generation: 1,
    registeredInCentral: false,
    registryStatus: 'idle', // 'idle' | 'registering' | 'registered' | 'error' | 'closed'
    registryError: null,
  };

  function updateStats(partial) {
    Object.assign(stats, partial);
    if (onStatsChange) {
      try {
        onStatsChange({ ...stats });
      } catch (e) {
        console.error('[RTC-PUB] Erro no callback de stats:', e);
      }
    }
  }

  function getOpenChannels() {
    const list = [];
    peers.forEach((peer) => {
      if (peer.dc && peer.dc.readyState === 'open') {
        list.push(peer.dc);
      }
    });
    return list;
  }

  function sendData(msgObject) {
    if (isStopped) return false;
    const channels = getOpenChannels();
    if (channels.length === 0) return false;

    try {
      const json = JSON.stringify(msgObject);
      const byteSize = new Blob([json]).size;
      let sentCount = 0;

      channels.forEach((channel) => {
        try {
          channel.send(json);
          sentCount++;
        } catch (err) {
          console.warn('[RTC-PUB] Falha ao enviar para canal individual:', err);
        }
      });

      if (sentCount === 0) return false;

      const updatedRecent = [
        {
          id: `${Date.now()}_${stats.eventsSent}`,
          time: new Date().toLocaleTimeString(),
          type: msgObject.type,
          eventType: msgObject.eventType || msgObject.type,
          sizeBytes: byteSize,
          summary: msgObject.type === 'live_event' 
            ? `${msgObject.eventType} (${JSON.stringify(msgObject.payload || {}).slice(0, 60)})`
            : msgObject.type,
          payload: msgObject,
        },
        ...stats.recentEvents.slice(0, 19),
      ];

      updateStats({
        eventsSent: stats.eventsSent + 1,
        bytesSent: stats.bytesSent + byteSize,
        lastEventSent: msgObject,
        recentEvents: updatedRecent,
        activeConsumers: channels.length,
      });
      return true;
    } catch (e) {
      console.warn('[RTC-PUB] Erro ao enviar pelo DataChannel:', e);
      return false;
    }
  }

  function getRealInitialData() {
    let liveActivity = { items: [], lastMessage: null, lastEvent: null };
    let connections = {};
    let streamMeta = {};
    try {
      if (typeof window !== 'undefined') {
        const rawAct = localStorage.getItem('livenexus_active_live_activity');
        if (rawAct) liveActivity = JSON.parse(rawAct);
        const rawConn = localStorage.getItem('livenexus_active_connections');
        if (rawConn) connections = JSON.parse(rawConn);
        const rawMeta = localStorage.getItem('livenexus_active_stream_meta');
        if (rawMeta) streamMeta = JSON.parse(rawMeta);
      }
    } catch (e) {}

    return {
      timestamp: Date.now(),
      runtimeId,
      contentInfo: contentInfo || { contentType: 'general_session', contentId: 'all' },
      bridge: {
        liveActivity,
        connections,
        streamMeta,
      },
      scenes: {},
      allWidgetTemplates: {},
      userCentral: {},
      contentSpecific: null,
    };
  }

  function hookRealEvents() {
    if (eventsHooked) return;
    eventsHooked = true;
    unsubBridge = null;
    unsubScene = null;
  }

  async function createAndSendOfferForPeer(consumerId = 'default') {
    if (isStopped) return;
    let peer = peers.get(consumerId);
    if (!peer) {
      peer = createPeer(consumerId);
    }
    if (peer.isMakingOffer || !peer.pc) return;

    try {
      peer.isMakingOffer = true;
      const offer = await peer.pc.createOffer();
      if (isStopped || !peer.pc) return;
      await peer.pc.setLocalDescription(offer);
      signaling.sendOffer(peer.pc.localDescription, consumerId, { contentInfo });
    } catch (e) {
      console.error(`[RTC-PUB] Erro ao criar/enviar Offer para consumer ${consumerId}:`, e);
    } finally {
      if (peer) peer.isMakingOffer = false;
    }
  }

  function createPeer(consumerId = 'default') {
    const existing = peers.get(consumerId);
    if (existing) {
      try { if (existing.dc) existing.dc.close(); } catch {}
      try { if (existing.pc) existing.pc.close(); } catch {}
    }

    let peerPc = null;
    let peerDc = null;

    try {
      peerPc = new RTCPeerConnection(RTC_CONFIG);
    } catch (e) {
      console.error('[RTC-PUB] Erro ao instanciar RTCPeerConnection:', e);
      updateStats({ peerState: 'error', channelState: 'error' });
      return null;
    }

    peerDc = peerPc.createDataChannel('livenexus-rtc-live', { ordered: true });

    const peerObj = {
      consumerId,
      pc: peerPc,
      dc: peerDc,
      isMakingOffer: false,
    };
    peers.set(consumerId, peerObj);

    peerDc.onopen = () => {
      if (isStopped) return;
      const openCount = getOpenChannels().length;
      updateStats({
        channelState: 'open',
        activeConsumers: openCount,
        connectedAt: stats.connectedAt || new Date().toISOString(),
      });

      // Envia snapshot REAL inicial através do DataChannel para este novo canal
      const initialSnapshot = getRealInitialData();
      try {
        peerDc.send(JSON.stringify({
          type: 'initial_snapshot',
          data: initialSnapshot,
          timestamp: Date.now(),
        }));
      } catch (err) {
        console.warn('[RTC-PUB] Erro ao enviar snapshot inicial:', err);
      }

      // Conecta aos listeners de eventos reais
      hookRealEvents();
    };

    peerDc.onclose = () => {
      if (isStopped) return;
      const openCount = getOpenChannels().length;
      updateStats({
        activeConsumers: openCount,
        channelState: openCount > 0 ? 'open' : 'closed',
      });
    };

    peerDc.onerror = (err) => {
      console.warn(`[RTC-PUB] DataChannel error (consumer ${consumerId}):`, err);
    };

    peerPc.oniceconnectionstatechange = () => {
      if (isStopped || !peerPc) return;
      updateStats({ iceState: peerPc.iceConnectionState });
    };

    peerPc.onconnectionstatechange = () => {
      if (isStopped || !peerPc) return;
      updateStats({ peerState: peerPc.connectionState });
    };

    peerPc.onicecandidate = (ev) => {
      if (ev.candidate && signaling && !isStopped) {
        signaling.sendCandidate(ev.candidate, consumerId);
      }
    };

    updateStats({ peerState: peerPc.connectionState, channelState: peerDc.readyState });
    return peerObj;
  }

  function init() {
    signaling = createRtcSignaling(runtimeId, 'publisher');

    // Consumer avisa que está pronto na página dele
    signaling.onReady((metadata, senderId) => {
      const consumerId = senderId || metadata?.consumerId || 'default';
      createAndSendOfferForPeer(consumerId);
    });

    signaling.onAnswer(async (sdp, senderId) => {
      if (isStopped) return;
      const consumerId = senderId || 'default';
      const peer = peers.get(consumerId) || (peers.size === 1 ? peers.values().next().value : null);
      if (!peer || !peer.pc) return;

      try {
        if (peer.pc.signalingState === 'have-local-offer') {
          await peer.pc.setRemoteDescription(new RTCSessionDescription(sdp));
        }
      } catch (e) {
        console.error(`[RTC-PUB] Erro ao definir remote answer para ${consumerId}:`, e);
      }
    });

    signaling.onCandidate(async (candidate, senderId) => {
      if (isStopped || !candidate) return;
      const consumerId = senderId || 'default';
      const peer = peers.get(consumerId) || (peers.size === 1 ? peers.values().next().value : null);
      if (!peer || !peer.pc) return;

      try {
        await peer.pc.addIceCandidate(new RTCIceCandidate(candidate));
      } catch (e) {
        console.warn(`[RTC-PUB] Erro ao adicionar ICE candidate para ${consumerId}:`, e);
      }
    });

    signaling.onClose((senderId) => {
      if (senderId && peers.has(senderId)) {
        const peer = peers.get(senderId);
        try { if (peer.dc) peer.dc.close(); } catch {}
        try { if (peer.pc) peer.pc.close(); } catch {}
        peers.delete(senderId);
        updateStats({ activeConsumers: getOpenChannels().length });
      }
    });

    // Cria a primeira conexão e oferta padrão
    createAndSendOfferForPeer('default');

    // Registra o runtimeId ativo deste conteúdo no rtcRegistry do usuário (D1 + Central)
    if (contentInfo && contentInfo.valid && contentInfo.contentId) {
      updateStats({ registryStatus: 'registering', registryError: null });
      registerRtcRuntime({
        contentType: contentInfo.contentType,
        contentId: contentInfo.contentId,
        runtimeId,
        status: 'active',
      }).then((regResult) => {
        if (!isStopped && regResult) {
          updateStats({
            generation: regResult.generation,
            registeredInCentral: true,
            registryStatus: 'registered',
            registryError: null,
          });
        }
      }).catch((err) => {
        console.error('[RTC-PUB] Erro REAL ao registrar runtime no rtcRegistry (D1):', err);
        if (!isStopped) {
          updateStats({
            registeredInCentral: false,
            registryStatus: 'error',
            registryError: err?.message || String(err),
          });
        }
      });
    }
  }

  init();

  return {
    runtimeId,
    stats,
    stop: () => {
      isStopped = true;
      if (contentInfo && contentInfo.valid && contentInfo.contentId) {
        unregisterRtcRuntime({
          contentType: contentInfo.contentType,
          contentId: contentInfo.contentId,
          runtimeId,
        }).catch((err) => {
          console.error('[RTC-PUB] Erro ao desregistrar runtime no rtcRegistry (D1):', err);
        });
      }
      if (unsubBridge) { try { unsubBridge(); } catch {} unsubBridge = null; }
      if (unsubScene) { try { unsubScene(); } catch {} unsubScene = null; }

      peers.forEach((peer) => {
        try { if (peer.dc) peer.dc.close(); } catch {}
        try { if (peer.pc) peer.pc.close(); } catch {}
      });
      peers.clear();

      if (signaling) {
        try { signaling.sendClose(); signaling.close(); } catch {}
        signaling = null;
      }
      updateStats({ peerState: 'closed', channelState: 'closed', registeredInCentral: false, registryStatus: 'closed', activeConsumers: 0 });
    },
    sendManualPulse: (customTag = 'manual_pulse') => {
      return sendData({
        type: 'live_event',
        eventType: 'rtc.pulse',
        payload: {
          tag: customTag,
          sentFrom: 'Publisher Lab',
          bridgeViewers: {},
        },
        timestamp: Date.now(),
      });
    },
    sendEvent: (eventType, payload) => {
      return sendData({
        type: 'live_event',
        eventType,
        payload,
        timestamp: Date.now(),
      });
    },
    sendSceneUpdate: (scene) => {
      return sendData({
        type: 'scene_update',
        sceneId: scene?.id,
        scene,
        timestamp: Date.now(),
      });
    },
  };
}
