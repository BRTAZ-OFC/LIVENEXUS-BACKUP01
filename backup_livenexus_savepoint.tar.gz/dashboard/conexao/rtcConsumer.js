// WebRTC Consumer Controller para Laboratório RTC Manual.
// Responsabilidade:
// 1. Conectar à sessão específica identificada por runtimeId.
// 2. Negociar conexão WebRTC com o Publisher via sinalização.
// 3. Abrir RTCDataChannel (via ondatachannel).
// 4. Receber dados reais, manter liveState atualizado para renderização e notificar subscribers.
// 5. Cleanup completo ao desconectar ou desmontar.

import { createRtcSignaling } from './rtcSignaling';

const RTC_CONFIG = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

export function createRtcConsumer({ runtimeId, onStatsChange, onStateChange }) {
  if (!runtimeId || typeof runtimeId !== 'string') {
    throw new Error('runtimeId é obrigatório para iniciar o Consumer');
  }

  const consumerId = `con_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  let pc = null;
  let dc = null;
  let signaling = null;
  let isStopped = false;
  let isNegotiating = false;
  const pendingCandidates = [];

  // Estado live reconstruído a partir dos dados recebidos via RTCDataChannel
  let liveBridgeState = null;
  let liveSceneData = null;
  let liveWidgetConfig = null;
  let liveScenesMap = {};
  let liveWidgetTemplatesMap = {};

  const stats = {
    runtimeId,
    consumerId,
    contentInfo: null,
    peerState: 'new',
    iceState: 'new',
    channelState: 'idle',
    eventsReceived: 0,
    bytesReceived: 0,
    lastEventReceived: null,
    recentEvents: [],
    connectedAt: null,
  };

  function updateStats(partial) {
    Object.assign(stats, partial);
    if (onStatsChange) {
      try {
        onStatsChange({ ...stats });
      } catch (e) {
        console.error('[RTC-CON] Erro no callback de stats:', e);
      }
    }
  }

  function notifyStateChange() {
    if (onStateChange) {
      try {
        onStateChange({
          contentInfo: stats.contentInfo,
          bridgeState: liveBridgeState,
          sceneData: liveSceneData,
          widgetConfig: liveWidgetConfig,
          scenesMap: liveScenesMap,
          widgetTemplatesMap: liveWidgetTemplatesMap,
        });
      } catch (e) {
        console.error('[RTC-CON] Erro no callback de stateChange:', e);
      }
    }
  }

  function handleDataMessage(ev) {
    if (isStopped || !ev.data) return;
    try {
      const rawData = ev.data;
      const byteSize = new Blob([rawData]).size;
      const parsed = JSON.parse(rawData);

      let contentInfoUpdate = null;

      if (parsed.type === 'initial_snapshot' && parsed.data) {
        const snap = parsed.data;
        if (snap.contentInfo) {
          contentInfoUpdate = snap.contentInfo;
        }
        if (snap.bridge) {
          liveBridgeState = snap.bridge;
          try {
            if (snap.bridge.liveActivity) {
              localStorage.setItem('livenexus_active_live_activity', JSON.stringify(snap.bridge.liveActivity));
            }
            if (snap.bridge.connections) {
              localStorage.setItem('livenexus_active_connections', JSON.stringify(snap.bridge.connections));
            }
            if (snap.bridge.streamMeta) {
              localStorage.setItem('livenexus_active_stream_meta', JSON.stringify(snap.bridge.streamMeta));
            }
          } catch (e) {}
        }
        if (snap.scenes) {
          liveScenesMap = snap.scenes;
        }
        if (snap.allWidgetTemplates) {
          liveWidgetTemplatesMap = snap.allWidgetTemplates;
        }
        if (snap.contentSpecific?.scene) {
          liveSceneData = snap.contentSpecific.scene;
        }
        if (snap.contentSpecific?.widgetTemplateConfig) {
          liveWidgetConfig = snap.contentSpecific.widgetTemplateConfig;
        }
        notifyStateChange();
      } else if (parsed.type === 'scenes_sync' && parsed.scenes) {
        liveScenesMap = parsed.scenes;
        notifyStateChange();
      } else if (parsed.type === 'live_event') {
        if (parsed.eventType === 'NEW_LIVE_ACTIVITY' && parsed.payload?.item && liveBridgeState) {
          const item = parsed.payload.item;
          const currentAct = liveBridgeState.liveActivity || { items: [], lastMessage: null, lastEvent: null };
          const nextAct = {
            items: [item, ...currentAct.items.filter(i => i.id !== item.id)].slice(0, 200),
            lastMessage: item.eventType ? currentAct.lastMessage : item,
            lastEvent: item.eventType ? item : currentAct.lastEvent,
          };
          liveBridgeState = {
            ...liveBridgeState,
            liveActivity: nextAct,
            lastEvent: { type: parsed.eventType, payload: parsed.payload },
            ...(typeof parsed.sequence === 'number' ? { sequence: parsed.sequence } : {}),
          };
        } else if (parsed.eventType && liveBridgeState) {
          liveBridgeState = {
            ...liveBridgeState,
            lastEvent: { type: parsed.eventType, payload: parsed.payload },
            ...(typeof parsed.sequence === 'number' ? { sequence: parsed.sequence } : {}),
          };
        }
        notifyStateChange();
      } else if (parsed.type === 'scene_update' && parsed.scene) {
        liveSceneData = parsed.scene;
        if (parsed.sceneId) {
          liveScenesMap = { ...liveScenesMap, [parsed.sceneId]: parsed.scene };
        }
        notifyStateChange();
      }

      const updatedRecent = [
        {
          id: `${Date.now()}_${stats.eventsReceived}`,
          time: new Date().toLocaleTimeString(),
          type: parsed.type,
          eventType: parsed.eventType || parsed.type,
          sizeBytes: byteSize,
          summary: parsed.type === 'live_event'
            ? `${parsed.eventType} (${JSON.stringify(parsed.payload || {}).slice(0, 60)})`
            : parsed.type,
          payload: parsed,
        },
        ...stats.recentEvents.slice(0, 19),
      ];

      updateStats({
        eventsReceived: stats.eventsReceived + 1,
        bytesReceived: stats.bytesReceived + byteSize,
        lastEventReceived: parsed,
        contentInfo: contentInfoUpdate || stats.contentInfo,
        recentEvents: updatedRecent,
      });
    } catch (e) {
      console.warn('[RTC-CON] Erro ao parsear mensagem do DataChannel:', e);
    }
  }

  function setupDataChannel(channel) {
    dc = channel;
    updateStats({ channelState: dc.readyState });

    dc.onopen = () => {
      if (isStopped) return;
      updateStats({ channelState: 'open', connectedAt: new Date().toISOString() });
    };

    dc.onclose = () => {
      if (isStopped) return;
      updateStats({ channelState: 'closed' });
    };

    dc.onerror = (err) => {
      console.warn('[RTC-CON] DataChannel error:', err);
    };

    dc.onmessage = handleDataMessage;
  }

  async function handleOffer(sdp, metadata) {
    if (isStopped || !pc || isNegotiating) return;
    try {
      isNegotiating = true;
      if (metadata?.contentInfo) {
        updateStats({ contentInfo: metadata.contentInfo });
        notifyStateChange();
      }

      await pc.setRemoteDescription(new RTCSessionDescription(sdp));

      // Aplica candidatos que chegaram antes da offer
      while (pendingCandidates.length > 0) {
        const candidate = pendingCandidates.shift();
        try {
          await pc.addIceCandidate(new RTCIceCandidate(candidate));
        } catch {}
      }

      const answer = await pc.createAnswer();
      if (isStopped || !pc) return;
      await pc.setLocalDescription(answer);

      signaling.sendAnswer(pc.localDescription, consumerId);
    } catch (e) {
      console.error('[RTC-CON] Erro ao processar offer / criar answer:', e);
    } finally {
      isNegotiating = false;
    }
  }

  function init() {
    signaling = createRtcSignaling(runtimeId, 'consumer', consumerId);

    try {
      pc = new RTCPeerConnection(RTC_CONFIG);
    } catch (e) {
      console.error('[RTC-CON] Erro ao instanciar RTCPeerConnection:', e);
      updateStats({ peerState: 'error', channelState: 'error' });
      return;
    }

    pc.ondatachannel = (ev) => {
      if (ev.channel) {
        setupDataChannel(ev.channel);
      }
    };

    pc.oniceconnectionstatechange = () => {
      if (isStopped || !pc) return;
      updateStats({ iceState: pc.iceConnectionState });
    };

    pc.onconnectionstatechange = () => {
      if (isStopped || !pc) return;
      updateStats({ peerState: pc.connectionState });
    };

    pc.onicecandidate = (ev) => {
      if (ev.candidate && signaling && !isStopped) {
        signaling.sendCandidate(ev.candidate, consumerId);
      }
    };

    signaling.onOffer((sdp, metadata) => {
      handleOffer(sdp, metadata);
    });

    signaling.onCandidate(async (candidate) => {
      if (isStopped || !candidate) return;
      if (!pc || !pc.remoteDescription) {
        pendingCandidates.push(candidate);
        return;
      }
      try {
        await pc.addIceCandidate(new RTCIceCandidate(candidate));
      } catch (e) {
        console.warn('[RTC-CON] Erro ao adicionar ICE candidate:', e);
      }
    });

    signaling.onClose(() => {
      updateStats({ peerState: 'disconnected', channelState: 'closed' });
    });

    updateStats({ peerState: pc.connectionState });

    // Notifica o Publisher de que este Consumer está online e pronto
    signaling.sendReady({ consumerId });
  }

  init();

  return {
    runtimeId,
    consumerId,
    stats,
    getLiveState: () => ({
      contentInfo: stats.contentInfo,
      bridgeState: liveBridgeState,
      sceneData: liveSceneData,
      widgetConfig: liveWidgetConfig,
      scenesMap: liveScenesMap,
      widgetTemplatesMap: liveWidgetTemplatesMap,
    }),
    stop: () => {
      isStopped = true;
      if (dc) {
        try { dc.close(); } catch {}
        dc = null;
      }
      if (pc) {
        try { pc.close(); } catch {}
        pc = null;
      }
      if (signaling) {
        try { signaling.sendClose(consumerId); signaling.close(); } catch {}
        signaling = null;
      }
      updateStats({ peerState: 'closed', channelState: 'closed' });
    },
  };
}
