// rtcRegistryService.js — Registro de runtimes RTC e fronteira de persistência.
// Registra dinamicamente os runtimeIds ativos de cenas, overlays e sessões de usuário.
// Zero polling, zero escrita por mensagens/eventos live. Persistência estrita em eventos de ciclo de vida RTC.


import { authClient } from '@dashboard/login/authClient';

let inMemoryRegistry = { scenes: {}, overlays: {}, user_sessions: {} };
let pendingPersist = Promise.resolve();

const categories = {
  scene: 'scenes',
  overlay: 'overlays',
  user_session: 'user_sessions',
};

function getCategory(contentType) {
  if (!Object.hasOwn(categories, contentType)) {
    throw new Error(`Tipo de conteúdo RTC não suportado: ${contentType}`);
  }
  return categories[contentType];
}

async function persistRtcRegistry(registry) {
  const write = async () => {
    const token = authClient?.getToken ? authClient.getToken() : null;
    const response = await fetch('/api/auth/update-me', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      },
      credentials: 'include',
      body: JSON.stringify({ data: { rtcRegistry: registry } }),
    });
    if (!response.ok) {
      throw new Error(`Falha ao persistir registro RTC (HTTP ${response.status})`);
    }
    if (!response.headers.get('content-type')?.includes('application/json')) {
      throw new Error('Resposta inválida ao persistir registro RTC');
    }
  };
  // As escritas são snapshots completos: manter a ordem impede que um snapshot
  // antigo da sessão sobrescreva a associação de cenário/overlay recém-criada.
  pendingPersist = pendingPersist.catch(() => {}).then(write);
  return pendingPersist;
}

export function getRtcRegistryFromCentral() {
  return {
    scenes: { ...(inMemoryRegistry.scenes || {}) },
    overlays: { ...(inMemoryRegistry.overlays || {}) },
    user_sessions: { ...(inMemoryRegistry.user_sessions || {}) },
  };
}

export function getActiveRuntime(contentType, contentId, userId) {
  if (!contentType || !contentId) return null;
  const category = getCategory(contentType);
  const entry = inMemoryRegistry[category]?.[contentId] || null;
  return entry && (!userId || entry.userId === userId) ? entry : null;
}

export async function registerRtcRuntime({ contentType, contentId, runtimeId, userId, status = 'active' }) {
  if (!contentType || !contentId || !runtimeId) {
    throw new Error('contentType, contentId e runtimeId são obrigatórios para registrar runtime RTC');
  }

  const category = getCategory(contentType);
  const ownerId = contentType === 'user_session' ? contentId : userId;
  if (!ownerId) {
    throw new Error('userId é obrigatório para registrar cenário ou overlay RTC');
  }
  const targetCategoryMap = inMemoryRegistry[category] || {};

  const prevEntry = targetCategoryMap[contentId];
  const generation = prevEntry ? (Number(prevEntry.generation) || 1) + 1 : 1;
  const updatedAt = new Date().toISOString();

  const newEntry = {
    userId: ownerId,
    runtimeId,
    generation,
    status,
    updatedAt,
  };

  const nextRegistry = {
    ...inMemoryRegistry,
    [category]: { ...targetCategoryMap, [contentId]: newEntry },
  };

  inMemoryRegistry = nextRegistry;

  await persistRtcRegistry(nextRegistry);

  return newEntry;
}

export async function unregisterRtcRuntime({ contentType, contentId, runtimeId, userId }) {
  if (!contentType || !contentId) return null;

  const category = getCategory(contentType);
  const targetCategoryMap = inMemoryRegistry[category] || {};

  const currentEntry = targetCategoryMap[contentId];
  if (!currentEntry || (runtimeId && currentEntry.runtimeId !== runtimeId) || (userId && currentEntry.userId !== userId)) {
    return null;
  }

  const updatedEntry = {
    ...currentEntry,
    status: 'closed',
    updatedAt: new Date().toISOString(),
  };

  const nextRegistry = {
    ...inMemoryRegistry,
    [category]: { ...targetCategoryMap, [contentId]: updatedEntry },
  };

  inMemoryRegistry = nextRegistry;

  await persistRtcRegistry(nextRegistry);

  return updatedEntry;
}
