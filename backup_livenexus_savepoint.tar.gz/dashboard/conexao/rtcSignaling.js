// Signaling Remoto Isolado para Laboratório WebRTC Manual usando ntfy.sh (HTTP EventSource/SSE).
// Permite sinalização WebRTC segura e em tempo real entre dispositivos diferentes (PC, Celular, Boosteroid, PRISM, etc).
// REGRAS ESTRITAS:
// - SOMENTE negociação WebRTC (runtimeId, ready, offer, answer, candidate, close, metadata mínima de identificação).
// - PROIBIDO trafegar chat, contadores, metas, snapshots ou eventos live aqui.
// - Sessão isolada por runtimeId único.
// - NÃO lê histórico antigo / sem ?since=all: apenas eventos em tempo real a partir da conexão.

export function createRtcSignaling(runtimeId, role = 'publisher', clientId = null) {
  if (!runtimeId || typeof runtimeId !== 'string') {
    throw new Error('runtimeId é obrigatório para inicializar sinalização WebRTC');
  }

  // Tópico isolado baseado no runtimeId único
  const topicName = `livenexus_rtc_${runtimeId.replace(/[^a-zA-Z0-9_-]/g, '')}`;
  const ntfyBase = 'https://ntfy.sh';
  
  let eventSource = null;
  let closed = false;
  let abortController = new AbortController();
  
  const listeners = {
    offer: new Set(),
    answer: new Set(),
    candidate: new Set(),
    ready: new Set(),
    close: new Set(),
  };

  const processedMsgIds = new Set();
  const sessionStartTime = Date.now() - 5000; // margem pequena para relógio, mas sem histórico antigo

  function handleIncoming(data) {
    if (closed || !data || data.runtimeId !== runtimeId) return;
    // Ignora mensagens enviadas pelo próprio papel ou cliente
    if (data.senderRole === role || (clientId && data.senderId === clientId)) return;
    // Se for consumer e a mensagem tiver targetId direcionado a outro consumer, ignora
    if (role === 'consumer' && clientId && data.targetId && data.targetId !== clientId) return;
    // Ignora mensagens antigas de antes da inicialização
    if (data.timestamp && data.timestamp < sessionStartTime) return;

    if (data.type === 'offer') {
      listeners.offer.forEach(fn => fn(data.sdp, data.metadata, data.targetId));
    } else if (data.type === 'answer') {
      listeners.answer.forEach(fn => fn(data.sdp, data.senderId));
    } else if (data.type === 'candidate') {
      listeners.candidate.forEach(fn => fn(data.candidate, data.senderId, data.targetId));
    } else if (data.type === 'ready') {
      listeners.ready.forEach(fn => fn(data.metadata, data.senderId));
    } else if (data.type === 'close') {
      listeners.close.forEach(fn => fn(data.senderId));
    }
  }

  // Conexão SSE (Server-Sent Events) com ntfy.sh para receber sinais remotos
  function initEventSource() {
    if (closed) return;
    try {
      // Usamos EventSource com stream json direto do ntfy.sh (sem since=all, apenas mensagens ao vivo)
      const sseUrl = `${ntfyBase}/${topicName}/sse`;
      eventSource = new EventSource(sseUrl);

      eventSource.onmessage = (event) => {
        if (closed) return;
        try {
          const sseData = JSON.parse(event.data);
          // O ntfy encapsula a mensagem no campo 'message' ou no próprio body
          if (sseData && sseData.message) {
            const parsed = JSON.parse(sseData.message);
            if (parsed && parsed.msgId) {
              if (processedMsgIds.has(parsed.msgId)) return;
              processedMsgIds.add(parsed.msgId);
              if (processedMsgIds.size > 200) {
                const first = processedMsgIds.values().next().value;
                processedMsgIds.delete(first);
              }
            }
            handleIncoming(parsed);
          }
        } catch {}
      };

      eventSource.onerror = () => {
        // EventSource tenta reconectar automaticamente
      };
    } catch (e) {
      console.warn('[RTC-REMOTE-SIGNAL] Erro ao instanciar EventSource:', e);
    }
  }

  // Envio de sinal via HTTP POST para o tópico remoto ntfy
  async function send(type, payload = {}) {
    if (closed) return;
    const msgId = `${role}_${type}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const msg = {
      msgId,
      runtimeId,
      senderRole: role,
      senderId: clientId || (role === 'publisher' ? 'pub' : null),
      type,
      timestamp: Date.now(),
      ...payload,
    };

    processedMsgIds.add(msgId);

    try {
      await fetch(`${ntfyBase}/${topicName}`, {
        method: 'POST',
        body: JSON.stringify(msg),
        headers: {
          'Content-Type': 'text/plain; charset=utf-8',
        },
        signal: abortController.signal,
      });
    } catch (e) {
      if (!closed) {
        console.warn(`[RTC-REMOTE-SIGNAL] Erro ao postar sinal '${type}':`, e);
      }
    }
  }

  initEventSource();

  return {
    runtimeId,
    role,
    clientId,
    sendReady: (metadata = {}) => send('ready', { metadata }),
    sendOffer: (sdp, targetId = null, metadata = {}) => send('offer', { sdp, targetId, metadata }),
    sendAnswer: (sdp, targetId = null) => send('answer', { sdp, targetId }),
    sendCandidate: (candidate, targetId = null) => send('candidate', { candidate, targetId }),
    sendClose: (targetId = null) => send('close', { targetId }),
    onOffer: (fn) => { listeners.offer.add(fn); return () => listeners.offer.delete(fn); },
    onAnswer: (fn) => { listeners.answer.add(fn); return () => listeners.answer.delete(fn); },
    onCandidate: (fn) => { listeners.candidate.add(fn); return () => listeners.candidate.delete(fn); },
    onReady: (fn) => { listeners.ready.add(fn); return () => listeners.ready.delete(fn); },
    onClose: (fn) => { listeners.close.add(fn); return () => listeners.close.delete(fn); },
    close: () => {
      closed = true;
      abortController.abort();
      if (eventSource) {
        try {
          eventSource.close();
        } catch {}
        eventSource = null;
      }
      listeners.offer.clear();
      listeners.answer.clear();
      listeners.candidate.clear();
      listeners.ready.clear();
      listeners.close.clear();
      processedMsgIds.clear();
    }
  };
}
