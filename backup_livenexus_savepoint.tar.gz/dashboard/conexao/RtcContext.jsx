import React, { createContext, useContext, useEffect, useState } from 'react';
import { useAuth } from '@dashboard/login/AuthContext';
import { useNewUserDataCentral } from '@dashboard/configuracao/DataCentral_NewUserDataCentral';
import { startUserRtcPublisher, stopUserRtcPublisher, subscribeRtcPublisherManager, getActiveRtcRuntimeForUser } from '@dashboard/conexao/rtcPublisherManager';
import { registerRtcRuntime, unregisterRtcRuntime } from '@dashboard/conexao/rtcRegistryService';

const RtcContext = createContext(null);

export function RtcProvider({ children }) {
  const { user, isAuthenticated } = useAuth();
  const central = useNewUserDataCentral();
  const [rtcState, setRtcState] = useState({ isRunning: false, runtimeId: null, stats: null });

  useEffect(() => {
    const unsub = subscribeRtcPublisherManager(setRtcState);
    return unsub;
  }, []);

  useEffect(() => {
    if (isAuthenticated && user?.id) {
      startUserRtcPublisher({ user });
    } else {
      stopUserRtcPublisher();
    }
  }, [isAuthenticated, user]);

  return (
    <RtcContext.Provider value={rtcState}>
      {children}
    </RtcContext.Provider>
  );
}

export function useActiveRtcSession() {
  const state = useContext(RtcContext);
  return state || { isRunning: false, runtimeId: null, stats: null };
}

export function useRegisterActiveRtcContent(contentType, contentId) {
  const { user, isAuthenticated } = useAuth();
  const { runtimeId } = useActiveRtcSession();
  const userId = user?.id;

  useEffect(() => {
    if (!isAuthenticated || !userId || !contentId || !runtimeId ||
        getActiveRtcRuntimeForUser(userId) !== runtimeId) return;

    const identity = { userId, contentType, contentId, runtimeId };
    registerRtcRuntime(identity).catch((error) => {
      console.error('[RTC] Falha ao registrar conteúdo ativo:', error);
    });

    return () => {
      unregisterRtcRuntime(identity).catch((error) => {
        console.error('[RTC] Falha ao desregistrar conteúdo ativo:', error);
      });
    };
  }, [isAuthenticated, userId, contentType, contentId, runtimeId]);
}
