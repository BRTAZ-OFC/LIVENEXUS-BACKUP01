// RtcPublisherManager — Gerenciador do Publisher WebRTC Automático por Usuário.
// Responsabilidade:
// 1. Iniciar automaticamente 1 Publisher WebRTC quando a sessão do usuário estiver ativa.
// 2. Garantir que exista apenas UM Publisher ativo por usuário/sessão (impedir duplicação).
// 3. Fornecer o runtimeId ativo daquele usuário para alimentar todos os seus Receivers (cenários e overlays).
// 4. Manter o ciclo de vida e executar cleanup ao encerrar sessão ou fazer logout.
// 5. Utilizar estritamente a fórmula comprovada createRtcPublisher().

import { createRtcPublisher } from './rtcPublisher';

let activePublisherInstance = null;
let activeUserSessionKey = null;
const managerListeners = new Set();

function notifyManagerListeners() {
  const currentSnapshot = {
    isRunning: !!activePublisherInstance,
    runtimeId: activePublisherInstance ? activePublisherInstance.runtimeId : null,
    stats: activePublisherInstance ? activePublisherInstance.stats : null,
  };
  managerListeners.forEach((fn) => {
    try {
      fn(currentSnapshot);
    } catch (e) {
      console.error('[RTC-MANAGER] Erro no listener do manager:', e);
    }
  });
}

export function startUserRtcPublisher({ user, forced = false }) {
  const userId = user?.id || user?.email || 'authenticated_user';
  const sessionKey = `${userId}`;

  if (activePublisherInstance && activeUserSessionKey === sessionKey && !forced) {
    return activePublisherInstance;
  }

  // Se já havia um publisher de outro usuário/sessão, encerra antes
  if (activePublisherInstance) {
    try {
      activePublisherInstance.stop();
    } catch {}
    activePublisherInstance = null;
    activeUserSessionKey = null;
  }

  const cleanUserTag = userId.replace(/[^a-zA-Z0-9]/g, '').slice(0, 10) || 'live';
  const runtimeId = '1222452';

  const contentInfo = {
    contentType: 'user_session',
    contentId: userId,
    label: user?.name || user?.email || 'Live Session',
    valid: true,
  };

  const publisher = createRtcPublisher({
    contentInfo,
    customRuntimeId: runtimeId,
    onStatsChange: () => {
      notifyManagerListeners();
    },
  });

  activePublisherInstance = publisher;
  activeUserSessionKey = sessionKey;
  notifyManagerListeners();

  return publisher;
}

export function stopUserRtcPublisher() {
  if (activePublisherInstance) {
    try {
      activePublisherInstance.stop();
    } catch (e) {
      console.warn('[RTC-MANAGER] Erro ao parar publisher:', e);
    }
    activePublisherInstance = null;
    activeUserSessionKey = null;
    notifyManagerListeners();
  }
}

export function getActiveRtcPublisher() {
  return activePublisherInstance;
}

export function getActiveRtcRuntimeId() {
  return activePublisherInstance ? activePublisherInstance.runtimeId : null;
}

export function getActiveRtcRuntimeForUser(userId) {
  return userId && activeUserSessionKey === String(userId)
    ? getActiveRtcRuntimeId()
    : null;
}

export function subscribeRtcPublisherManager(fn) {
  managerListeners.add(fn);
  fn({
    isRunning: !!activePublisherInstance,
    runtimeId: activePublisherInstance ? activePublisherInstance.runtimeId : null,
    stats: activePublisherInstance ? activePublisherInstance.stats : null,
  });
  return () => managerListeners.delete(fn);
}
