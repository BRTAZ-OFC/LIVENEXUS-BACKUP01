import React, { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowLeft, Edit3, RefreshCw, Trash2, Check, X } from 'lucide-react';
import { useNewUserDataCentral } from '@dashboard/configuracao/DataCentral_NewUserDataCentral';
import { removeGalleryImage, hydrateUserGallery } from '@dashboard/painel-admin/Gallery_mediaStorageAdapter';

const titles = { scenarios: 'Cenários', overlays: 'Overlays', gallery: 'Galeria', library: 'Biblioteca' };
const libraryKinds = { songs: 'song', albums: 'album', artists: 'artist', playlists: 'playlist' };

const editableFields = {
  scenarios: ['name', 'description'],
  overlays: ['name', 'description'],
  gallery: ['title', 'name', 'description', 'caption'],
  library: ['name', 'title', 'description'],
};

const labels = {
  id: 'ID', mediaId: 'ID da mídia', videoId: 'ID do vídeo', userId: 'Usuário',
  name: 'Nome', title: 'Título', description: 'Descrição', caption: 'Legenda',
  mode: 'Modo', category: 'Categoria', type: 'Tipo', background: 'Background',
  thumbnail: 'Miniatura', cover: 'Capa', image: 'Imagem', url: 'Endereço',
  localPath: 'Caminho', filename: 'Arquivo', source: 'Origem',
  instances: 'Elementos', subcenarios: 'Subcenários', visualizerSize: 'Tamanho',
  gridSettings: 'Grade', activeSubcenarioId: 'Subcenário ativo',
};

const label = field => labels[field] || field.replace(/([a-z])([A-Z])/g, '$1 $2');
const itemId = record => record?.id || record?.mediaId || record?.videoId;

const rowsFor = (domain, data) => domain === 'library'
  ? Object.entries(libraryKinds).flatMap(([field, kind]) =>
    (Array.isArray(data?.[field]) ? data[field] : []).map(record => ({ record, kind })))
  : (Array.isArray(data) ? data : []).map(record => ({ record }));

const imageFor = (domain, record) => {
  if (!record) return null;
  if (domain === 'scenarios') return record.thumbnail || record.background?.image || record.subcenarios?.[0]?.background?.image;
  if (domain === 'overlays') return record.thumbnail || record.preview || record.background?.image;
  if (domain === 'gallery') return record.url || record.thumbnail;
  return record.thumbnail || record.cover || record.image;
};

const titleFor = record => record?.name || record?.title || record?.filename || (record ? itemId(record) : 'Item');

function Preview({ src, alt, large = false }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [src]);
  const size = large ? 'w-full h-48' : 'w-full h-28';
  return src && !failed
    ? <img src={src} alt={alt} onError={() => setFailed(true)} className={`${size} object-contain bg-black/40 rounded-lg`} />
    : <div role="img" aria-label="Sem miniatura disponível" className={`${size} bg-white/5 border border-white/10 rounded-lg flex items-center justify-center text-xs text-slate-500`}>Sem miniatura</div>;
}

function Field({ name, value }) {
  if (value == null || value === '') return null;
  if (Array.isArray(value)) return (
    <details className="rounded-lg border border-white/10 bg-black/20 p-3">
      <summary className="cursor-pointer text-xs text-violet-200">{label(name)} · {value.length} {value.length === 1 ? 'item' : 'itens'}</summary>
      <div className="space-y-2 mt-3">
        {value.map((item, index) => <Field key={index} name={item?.name || item?.title || `Item ${index + 1}`} value={item} />)}
      </div>
    </details>
  );
  if (typeof value === 'object') return (
    <details className="rounded-lg border border-white/10 bg-black/20 p-3">
      <summary className="cursor-pointer text-xs text-violet-200">{label(name)}</summary>
      <div className="grid gap-2 mt-3">{Object.entries(value).map(([key, nested]) =>
        <Field key={key} name={key} value={nested} />)}</div>
    </details>
  );
  return <div className="rounded-lg border border-white/10 bg-black/20 p-3 min-w-0">
    <p className="text-[10px] uppercase tracking-wide text-slate-500">{label(name)}</p>
    <p className="text-xs text-slate-200 break-all mt-1">{String(value)}</p>
  </div>;
}

export default function DocumentSections({ domain }) {
  const { userId, scenarioBranch, overlayBranch, galleryBranch, libraryBranch, documentRtcRegistry } = useNewUserDataCentral();
  const branch = { scenarios: scenarioBranch, overlays: overlayBranch, gallery: galleryBranch, library: libraryBranch }[domain];
  const active = useRef({ userId, domain });
  active.current = { userId, domain };

  const [rows, setRows] = useState([]);
  const [selected, setSelected] = useState(null);
  const [editing, setEditing] = useState(false);
  const [changes, setChanges] = useState({});
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [detailConfirmDelete, setDetailConfirmDelete] = useState(false);

  const current = () => active.current.userId === userId && active.current.domain === domain;

  const load = useCallback(async () => {
    if (!userId || !branch) return;
    setLoading(true);
    setError('');
    try {
      const data = await branch('GET');
      if (active.current.userId === userId && active.current.domain === domain) {
        setRows(rowsFor(domain, data));
      }
    } catch (failure) {
      if (active.current.userId === userId && active.current.domain === domain) {
        setError(failure.message);
      }
    } finally {
      if (active.current.userId === userId && active.current.domain === domain) {
        setLoading(false);
      }
    }
  }, [userId, domain, branch]);

  useEffect(() => {
    setRows([]);
    setSelected(null);
    setEditing(false);
    setConfirmDeleteId(null);
    setDetailConfirmDelete(false);
    setError('');
    load();
  }, [load]);

  const open = async (record, kind, startEditing = false) => {
    setError('');
    setConfirmDeleteId(null);
    setDetailConfirmDelete(false);
    try {
      const targetId = itemId(record);
      const result = await branch('GET', { id: targetId, kind });
      if (current()) {
        const docRecord = result || record;
        setSelected({ record: docRecord, kind });
        setChanges({});
        setEditing(startEditing);
      }
    } catch (failure) {
      if (current()) {
        setSelected({ record, kind });
        setChanges({});
        setEditing(startEditing);
      }
    }
  };

  const save = async () => {
    if (!selected || busy) return;
    const allowed = editableFields[domain] || [];
    const payload = Object.fromEntries(
      Object.entries(changes).filter(([field, value]) =>
        allowed.includes(field) && typeof value === 'string' && value !== (selected.record[field] ?? '')
      )
    );
    if (!Object.keys(payload).length) {
      setEditing(false);
      return;
    }
    setBusy(true);
    setError('');
    try {
      const targetId = itemId(selected.record);
      const updated = await branch('PATCH', { id: targetId, kind: selected.kind, payload: { changes: payload } });
      if (current()) {
        const nextRecord = updated || { ...selected.record, ...payload };
        setSelected({ ...selected, record: nextRecord });
        setEditing(false);
        setChanges({});
        await load();
      }
      if (domain === 'gallery') {
        hydrateUserGallery().catch(() => {});
      }
    } catch (failure) {
      if (current()) setError(failure.message);
    } finally {
      setBusy(false);
    }
  };

  const removeSelected = async () => {
    if (!selected || busy) return;
    setBusy(true);
    setError('');
    try {
      const targetId = itemId(selected.record);
      await branch('DELETE', { id: targetId, kind: selected.kind });
      if (domain === 'gallery') {
        removeGalleryImage(targetId);
      }
      if (current()) {
        setSelected(null);
        setEditing(false);
        setDetailConfirmDelete(false);
        await load();
      }
      if (domain === 'gallery') {
        hydrateUserGallery().catch(() => {});
      }
    } catch (failure) {
      if (current()) setError(failure.message);
    } finally {
      setBusy(false);
    }
  };

  const removeDirect = async (record, kind, e) => {
    if (e) e.stopPropagation();
    if (busy) return;
    const targetId = itemId(record);
    setBusy(true);
    setError('');
    try {
      await branch('DELETE', { id: targetId, kind });
      if (domain === 'gallery') {
        removeGalleryImage(targetId);
      }
      if (current()) {
        setConfirmDeleteId(null);
        if (selected && itemId(selected.record) === targetId) {
          setSelected(null);
          setEditing(false);
        }
        await load();
      }
      if (domain === 'gallery') {
        hydrateUserGallery().catch(() => {});
      }
    } catch (failure) {
      if (current()) setError(failure.message);
    } finally {
      setBusy(false);
    }
  };

  const runtime = selected && (domain === 'scenarios' || domain === 'overlays')
    ? (domain === 'scenarios' ? documentRtcRegistry?.scenes : documentRtcRegistry?.overlays)?.[String(itemId(selected.record))]
    : null;
  const runtimeId = runtime?.userId === userId && runtime?.status === 'active' ? runtime.runtimeId : null;

  return (
    <section aria-label={titles[domain]} id="central-document-sections" className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-xs text-slate-400">Documentos do Johnson de {titles[domain]}</p>
        <button
          type="button"
          onClick={load}
          disabled={!userId || loading}
          className="text-xs text-violet-300 disabled:opacity-50 flex items-center gap-1 hover:text-violet-200 transition"
        >
          <RefreshCw size={13} className={loading ? 'animate-spin' : ''} /> Atualizar
        </button>
      </div>

      {error && <p role="alert" className="text-xs text-red-300 bg-red-500/10 border border-red-500/20 rounded-lg p-3">{error}</p>}
      {!userId && <p className="text-xs text-slate-400">Aguardando identidade autenticada.</p>}

      {userId && !selected && (
        <div className="rounded-xl border border-white/10 bg-white/5 p-4 space-y-4">
          <div>
            <h3 className="text-sm text-white font-semibold">Usuário autenticado: {userId}</h3>
            <p className="text-xs text-slate-400">
              Registros da conta atual. Selecione uma miniatura para abrir os detalhes ou execute as ações diretamente nos cartões.
            </p>
          </div>

          {loading && !rows.length && <p className="text-xs text-slate-400">Carregando documentos…</p>}
          {!loading && !error && !rows.length && <p className="text-xs text-slate-400">Nenhum registro disponível para este usuário.</p>}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {rows.map(({ record, kind }) => {
              const id = itemId(record);
              const isConfirming = confirmDeleteId === id;

              return (
                <div
                  key={`${kind || domain}:${id}`}
                  className="group relative min-w-0 p-3 rounded-xl border border-white/10 bg-black/40 hover:border-violet-500/50 transition flex flex-col justify-between"
                >
                  <div className="cursor-pointer" onClick={() => open(record, kind)}>
                    <Preview src={imageFor(domain, record)} alt={titleFor(record)} />
                    <p className="text-xs font-medium text-white truncate mt-2 group-hover:text-violet-300 transition">
                      {titleFor(record)}
                    </p>
                    <p className="text-[10px] text-slate-400 truncate">{kind || id}</p>
                  </div>

                  {/* Ações da miniatura: Editar e Excluir */}
                  <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between gap-1">
                    {isConfirming ? (
                      <div className="w-full flex items-center justify-between gap-1 bg-red-950/60 p-1.5 rounded-lg border border-red-500/30">
                        <span className="text-[10px] text-red-200 font-medium">Excluir?</span>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={(e) => removeDirect(record, kind, e)}
                            disabled={busy}
                            title="Confirmar exclusão"
                            className="bg-red-600 hover:bg-red-500 text-white text-[10px] px-2 py-0.5 rounded font-medium disabled:opacity-50 transition flex items-center gap-0.5"
                          >
                            <Check size={10} /> Sim
                          </button>
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setConfirmDeleteId(null); }}
                            className="bg-white/10 hover:bg-white/20 text-slate-300 text-[10px] px-2 py-0.5 rounded transition flex items-center gap-0.5"
                          >
                            <X size={10} /> Não
                          </button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <button
                          type="button"
                          onClick={() => open(record, kind, true)}
                          className="flex-1 py-1 px-2 rounded-lg bg-white/5 hover:bg-violet-600/30 text-violet-300 text-xs font-medium flex items-center justify-center gap-1 transition"
                          title="Editar metadados"
                        >
                          <Edit3 size={12} /> Editar
                        </button>
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); setConfirmDeleteId(id); }}
                          disabled={busy}
                          className="flex-1 py-1 px-2 rounded-lg bg-white/5 hover:bg-red-600/30 text-red-300 text-xs font-medium flex items-center justify-center gap-1 transition disabled:opacity-50"
                          title="Excluir miniatura"
                        >
                          <Trash2 size={12} /> Excluir
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {selected && (
        <div className="rounded-xl border border-violet-500/30 bg-white/5 p-4 space-y-4" aria-label="Detalhes do documento">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => { setSelected(null); setEditing(false); setDetailConfirmDelete(false); }}
                className="text-violet-300 hover:text-violet-200 p-1 rounded-lg hover:bg-white/5 transition"
                aria-label="Voltar às miniaturas"
              >
                <ArrowLeft size={18} />
              </button>
              <h3 className="text-white font-semibold break-all text-base">{titleFor(selected.record)}</h3>
            </div>

            <div className="flex items-center gap-2">
              {!editing && !detailConfirmDelete && (
                <>
                  <button
                    type="button"
                    onClick={() => setEditing(true)}
                    className="text-xs bg-violet-600/30 hover:bg-violet-600/50 border border-violet-500/40 text-violet-200 rounded-lg px-3 py-1.5 flex items-center gap-1.5 transition"
                  >
                    <Edit3 size={13} /> Editar
                  </button>
                  <button
                    type="button"
                    onClick={() => setDetailConfirmDelete(true)}
                    disabled={busy}
                    className="text-xs bg-red-600/20 hover:bg-red-600/40 border border-red-500/40 text-red-300 rounded-lg px-3 py-1.5 flex items-center gap-1.5 transition disabled:opacity-50"
                  >
                    <Trash2 size={13} /> Excluir
                  </button>
                </>
              )}

              {detailConfirmDelete && (
                <div className="flex items-center gap-2 bg-red-950/70 border border-red-500/40 p-1.5 rounded-lg">
                  <span className="text-xs text-red-200 font-medium">Excluir este item?</span>
                  <button
                    type="button"
                    onClick={removeSelected}
                    disabled={busy}
                    className="text-xs bg-red-600 hover:bg-red-500 text-white rounded px-2.5 py-1 font-medium disabled:opacity-50 transition"
                  >
                    {busy ? 'Excluindo…' : 'Sim, Excluir'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setDetailConfirmDelete(false)}
                    className="text-xs bg-white/10 hover:bg-white/20 text-slate-300 rounded px-2.5 py-1 transition"
                  >
                    Cancelar
                  </button>
                </div>
              )}

              {editing && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={save}
                    disabled={busy}
                    className="text-xs bg-violet-600 hover:bg-violet-500 text-white font-medium rounded-lg px-3 py-1.5 disabled:opacity-50 transition"
                  >
                    {busy ? 'Salvando…' : 'Salvar Alterações'}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setEditing(false); setChanges({}); }}
                    className="text-xs bg-white/10 hover:bg-white/20 text-slate-300 rounded-lg px-3 py-1.5 transition"
                  >
                    Cancelar
                  </button>
                </div>
              )}
            </div>
          </div>

          <Preview src={imageFor(domain, selected.record)} alt={titleFor(selected.record)} large />

          {editing && (
            <div className="grid sm:grid-cols-2 gap-3 border border-violet-500/30 bg-black/40 rounded-xl p-4">
              {(editableFields[domain] || []).map(field => (
                <label key={field} className="text-xs text-slate-300 font-medium">
                  {label(field)}
                  <input
                    className="block w-full mt-1.5 bg-black/60 border border-white/15 focus:border-violet-500 rounded-lg px-3 py-2 text-white text-xs outline-none transition"
                    value={changes[field] ?? selected.record[field] ?? ''}
                    onChange={event => setChanges(state => ({ ...state, [field]: event.target.value }))}
                  />
                </label>
              ))}
              <p className="text-[11px] text-slate-500 sm:col-span-2">
                ID, proprietário, caminhos físicos de mídia, origem, configurações estruturais e RTC são somente leitura.
              </p>
            </div>
          )}

          {(domain === 'scenarios' || domain === 'overlays') && (
            <Field name="Runtime ID (somente leitura)" value={runtimeId || 'Não associado/indisponível'} />
          )}

          <div className="grid sm:grid-cols-2 gap-2">
            {Object.entries(selected.record).map(([field, value]) => (
              <Field key={field} name={field} value={value} />
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
