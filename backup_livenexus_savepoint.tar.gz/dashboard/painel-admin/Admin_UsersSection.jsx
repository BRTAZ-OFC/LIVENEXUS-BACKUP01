import { Users, Shield, UserCheck } from 'lucide-react';

export default function AdminUsersSection() {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <header className="space-y-1">
        <div className="flex items-center gap-2.5">
          <div className="grid h-9 w-9 place-items-center rounded-xl border border-violet-500/30 bg-violet-500/10 text-violet-300">
            <Users size={18} />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-white">Usuários</h2>
            <p className="text-xs text-slate-400">Gestão de contas, permissões e moderação administrativa</p>
          </div>
        </div>
      </header>

      <div className="rounded-2xl border border-white/10 bg-[#0a0d15] p-6 md:p-8 space-y-5">
        <div className="flex flex-col items-center justify-center text-center py-8 px-4 max-w-md mx-auto space-y-3">
          <div className="grid h-14 w-14 place-items-center rounded-2xl border border-white/10 bg-white/5 text-violet-300">
            <UserCheck size={26} />
          </div>
          <h3 className="text-base font-semibold text-white">Módulo de Gestão em Preparação</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            A estrutura administrativa para gerenciamento avançado de usuários, controle de permissões e auditoria de acessos está pronta para integração com o provedor de identidade.
          </p>
          <div className="flex items-center gap-2 pt-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-[11px] font-medium text-emerald-300">
              <Shield size={12} /> Acesso Restrito (Admin)
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
