import DataCentralPage from './Admin_DataCentralPage';

// O menu administrativo reutiliza a área documental de Avaliações da Central.
export default function AdminReviewsSection() {
  return <DataCentralPage initialDetail="reviews" />;
}
