import { useState } from 'react';
import { FlaskConical, ChevronRight, ChevronLeft, Sparkles, Box, Shield, Layers, HelpCircle, RadioTower, Image as ImageIcon, Database } from 'lucide-react';
import { useAutoScroll } from '@dashboard/componentes/useAutoScroll';
import YouTubeTest1Section from './lab/Admin_YouTubeTest1Section';
import ImageUploadTestSection from './lab/Admin_ImageUploadTestSection';
import D1UserGalleryTestSection from './lab/Gallery_D1UserGalleryTestSection';

const LAB_TOOLS = [
  {
    id: 'sandbox-overview',
    name: 'Visão Geral do Sandbox',
    category: 'Ambiente',
    icon: Box,
    description: 'Painel de isolamento para desenvolvimento e prototipagem de novos recursos.',
  },
  {
    id: 'youtube-test-1',
    name: 'Teste YouTube 1',
    category: 'Conexões & Streaming',
    icon: RadioTower,
    description: 'Conexão limpa com live pública sem Data API v3 · Bootstrap 1-shot + tentativa de chat direto pelo Frontend.',
  },
  {
    id: 'image-upload-test',
    name: 'Teste de Upload de Imagem',
    category: 'Upload & Mídia',
    icon: ImageIcon,
    description: 'Área própria para teste e validação de upload e processamento de imagens do dashboard.',
  },
  {
    id: 'd1-user-gallery',
    name: 'TESTE D1 → JOHNSON → CENTRAL → GALERIA DO USUÁRIO',
    category: 'Ambiente',
    icon: Database,
    description: 'Validação de persistência isolada por ID de usuário.',
  },
];

export default function AdminLabSection() {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [activeToolId, setActiveToolId] = useState('sandbox-overview');

  // Auto-scroll padronizado do LiveNexus nas zonas de borda do drawer (desktop)
  const {
    ref: drawerNavRef,
    handleMouseMove: handleDrawerMouseMove,
    stopAutoScroll: stopDrawerAutoScroll,
  } = useAutoScroll({
    zone: 70,
    minSpeed: 1.5,
    maxSpeed: 6.0,
    checkButtons: false,
  });

  const activeTool = LAB_TOOLS.find((t) => t.id === activeToolId) || LAB_TOOLS[0];

  return (
    <div className="relative w-full h-full min-h-[calc(100vh-6rem)] overflow-x-hidden flex flex-col">
      {/* Barra superior de controle do Lab */}
      <div className="flex items-center justify-between pb-4 mb-4 border-b border-white/10 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="grid h-9 w-9 place-items-center rounded-xl border border-violet-500/30 bg-violet-500/10 text-violet-300">
            <FlaskConical size={18} />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-white">Laboratório</h2>
            <p className="text-xs text-slate-400">Contêiner administrativo para experimentação e testes isolados</p>
          </div>
        </div>

        {/* Botão retrátil para abrir/fechar o Drawer de Ferramentas */}
        <button
          onClick={() => setDrawerOpen(!drawerOpen)}
          className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-semibold transition z-30 shadow-lg ${
            drawerOpen
              ? 'bg-violet-500 text-white shadow-violet-500/20'
              : 'border border-violet-500/30 bg-[#0e121d] text-violet-200 hover:bg-violet-500/20'
          }`}
          title={drawerOpen ? 'Recolher seletor de ferramentas' : 'Abrir seletor de ferramentas'}
        >
          <Layers size={14} />
          <span>Ferramentas</span>
          {drawerOpen ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
        </button>
      </div>

      {/* Área Principal da Ferramenta Ativa (NÃO é comprimida pelo drawer) */}
      <div className="flex-1 w-full min-w-0">
        {activeToolId === 'sandbox-overview' && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="rounded-2xl border border-white/10 bg-[#0a0d15] p-6 md:p-8 space-y-6">
              <div className="flex items-start gap-4">
                <div className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl border border-violet-500/30 bg-violet-500/10 text-violet-300">
                  <Sparkles size={24} />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-semibold text-white">Ambiente de Testes & Prototipagem</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    O Laboratório opera como um contêiner administrativo isolado. Experimentos desenvolvidos aqui não interferem no fluxo de produção de usuários comuns.
                  </p>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2 pt-2">
                <div className="rounded-xl border border-white/5 bg-white/[0.02] p-4 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-semibold text-violet-300">
                    <Shield size={15} />
                    <span>Isolamento Total</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Ferramentas no Laboratório têm ciclo de vida temporário. Recursos validados são promovidos para suas respectivas seções definitivas.
                  </p>
                </div>

                <div className="rounded-xl border border-white/5 bg-white/[0.02] p-4 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-semibold text-emerald-300">
                    <Box size={15} />
                    <span>Seletor Modular</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Abra o seletor lateral no topo direito para alternar entre as ferramentas experimentais disponíveis.
                  </p>
                </div>
              </div>

              <div className="rounded-xl border border-violet-500/20 bg-violet-500/5 p-4 flex items-center gap-3">
                <HelpCircle size={18} className="text-violet-300 shrink-0" />
                <p className="text-xs text-violet-200">
                  Novas ferramentas experimentais serão adicionadas individualmente neste contêiner conforme os ciclos de desenvolvimento do LiveNexus.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeToolId === 'youtube-test-1' && (
          <YouTubeTest1Section />
        )}

        {activeToolId === 'image-upload-test' && (
          <ImageUploadTestSection />
        )}
        {activeToolId === 'd1-user-gallery' && (
          <D1UserGalleryTestSection />
        )}
      </div>

      {/* Backdrop suave para fechar o drawer ao clicar fora em telas menores */}
      {drawerOpen && (
        <div
          onClick={() => {
            stopDrawerAutoScroll();
            setDrawerOpen(false);
          }}
          className="fixed md:hidden inset-0 bg-black/50 z-30 backdrop-blur-xs"
        />
      )}

      {/* Drawer Direito Retrátil (OVERLAY / OFF-CANVAS puro) */}
      <aside
        onMouseLeave={stopDrawerAutoScroll}
        className={`absolute top-0 right-0 h-full w-72 md:w-80 bg-[#0a0d15] border-l border-violet-500/25 shadow-2xl shadow-black/90 z-40 flex flex-col transition-transform duration-300 ease-in-out ${
          drawerOpen ? 'translate-x-0' : 'translate-x-full pointer-events-none'
        }`}
      >
        {/* Cabeçalho do Drawer */}
        <div className="px-4 py-4 border-b border-white/10 flex items-center justify-between bg-[#080b12] shrink-0">
          <div className="flex items-center gap-2">
            <Layers size={16} className="text-violet-300" />
            <span className="text-xs font-semibold text-white tracking-wide uppercase">Seletor de Ferramentas</span>
          </div>
          <button
            onClick={() => {
              stopDrawerAutoScroll();
              setDrawerOpen(false);
            }}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
            title="Fechar seletor"
          >
            <ChevronRight size={16} />
          </button>
        </div>

        {/* Lista de Ferramentas com AutoScroll suave no desktop + rolagem natural touch */}
        <div
          ref={drawerNavRef}
          onMouseMove={handleDrawerMouseMove}
          className="no-scrollbar flex-1 overflow-y-auto p-3 space-y-2 overscroll-contain"
        >
          <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider px-2 pt-1 pb-0.5">
            Ferramentas Disponíveis ({LAB_TOOLS.length})
          </p>

          {LAB_TOOLS.map((tool) => {
            const Icon = tool.icon;
            const isSelected = activeToolId === tool.id;
            return (
              <button
                key={tool.id}
                onClick={() => {
                  setActiveToolId(tool.id);
                  // Manter a ferramenta ativa sem necessariamente fechar o drawer no desktop
                }}
                className={`flex w-full flex-col text-left rounded-xl p-3 border transition ${
                  isSelected
                    ? 'border-violet-400/50 bg-violet-500/20 text-white shadow-sm ring-1 ring-violet-400/30'
                    : 'border-white/5 bg-white/[0.02] text-slate-300 hover:bg-white/5 hover:border-white/10'
                }`}
              >
                <div className="flex items-center gap-2.5 mb-1">
                  <Icon size={16} className={isSelected ? 'text-violet-300' : 'text-slate-400'} />
                  <span className="text-xs font-semibold text-white truncate">{tool.name}</span>
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">{tool.description}</p>
              </button>
            );
          })}
        </div>

        {/* Rodapé do Drawer */}
        <div className="p-3 border-t border-white/5 bg-[#080b12]/80 shrink-0 text-center">
          <span className="text-[10px] text-slate-500">LiveNexus Sandbox Architecture</span>
        </div>
      </aside>
    </div>
  );
}
