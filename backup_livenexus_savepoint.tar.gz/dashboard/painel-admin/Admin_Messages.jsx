// AdminMessages — Painel Administrativo > Mensagens / Contatos.
// Acesso exclusivo de admins (user.role === 'admin'). Lista registros Contact
// persistidos pelo Johnson de Mensagens via Central/ramal, permite mudar status e responder por e-mail
// via mailto (abre o provedor do dispositivo; o LiveNexus não envia o e-mail).
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@dashboard/login/AuthContext';
import { useNewUserDataCentral } from '@dashboard/configuracao/DataCentral_NewUserDataCentral';
import { ArrowLeft, Mail, Loader2, ShieldAlert, Inbox, Radio } from 'lucide-react';

const STATUS_OPTIONS = ['novo', 'lido', 'respondido'];

const STATUS_STYLES = {
  novo: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
  lido: 'bg-sky-500/15 text-sky-300 border-sky-500/30',
  respondido: 'bg-green-500/15 text-green-300 border-green-500/30',
};

function fmtDate(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '—';
  return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function buildMailto(m) {
  const subject = `Resposta LiveNexus — ${m.category || 'Contato'}`;
  const body = `Olá ${m.name},\n\nRecebemos sua mensagem enviada em ${fmtDate(m.created_date)}:\n\n"${m.message}"\n\n`;
  return `mailto:${m.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

export default function AdminMessages({ embedded = false }) {
  const { user, isLoadingAuth } = useAuth();
  const isAdmin = user?.role === 'admin' || user?.data?.role === 'admin';
  const central = useNewUserDataCentral();
  const checking = isLoadingAuth;
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isAdmin || checking) return;
    let active = true;
    central.messagesBranch('GET').then(items => {
      if (active) { setMessages(items); setError(''); }
    }).catch(err => {
      if (active) setError(err.message || 'Não foi possível carregar as mensagens.');
    }).finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [central.messagesBranch, isAdmin, checking]);

  const updateStatus = async (id, status) => {
    if (updatingId) return;
    setUpdatingId(id);
    try {
      const updated = await central.messagesBranch('PATCH', { id, payload: { status } });
      setMessages(previous => previous.map(m => m.id === id ? updated : m));
      setError('');
    } catch (e) {
      setError(e.message || 'Não foi possível atualizar a mensagem.');
    } finally {
      setUpdatingId(null);
    }
  };

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="animate-spin text-slate-500" size={26} />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center px-4 text-center">
        <ShieldAlert size={40} className="mb-4 text-red-400" />
        <h1 className="text-lg font-bold text-white">Acesso negado</h1>
        <p className="mt-2 text-sm text-slate-400">Esta área é restrita a administradores.</p>
        <Link to="/" className="mt-6 rounded-lg bg-white/5 px-4 py-2 text-sm text-slate-200 transition hover:bg-white/10">
          Voltar à página inicial
        </Link>
      </div>
    );
  }

  return (
    <div className={`${embedded ? 'min-h-full' : 'min-h-screen'} text-slate-200`}>
      {!embedded && <header className="sticky top-0 z-40 border-b border-white/10 bg-black/40 backdrop-blur-md">
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3.5 md:px-8">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-violet-600 to-indigo-600 text-white shadow-md shadow-violet-500/20">
              <Radio className="h-4 w-4 text-white" />
            </div>
            <span className="text-sm font-bold text-white">Painel Admin</span>
          </Link>
          <Link
            to="/"
            className="flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/5 px-4 py-2 text-[13px] font-medium text-slate-200 transition hover:bg-white/10"
          >
            <ArrowLeft size={14} /> Voltar à página inicial
          </Link>
        </nav>
      </header>}

      <div className="mx-auto max-w-5xl px-4 py-12 md:px-8">
        <div className="mb-6 flex items-center gap-2">
          <Inbox size={22} className="text-violet-300" />
          <h1 className="text-2xl font-bold text-white md:text-3xl">Mensagens / Contatos</h1>
          <span className="ml-auto text-xs text-slate-500">{messages.length} mensagem(s)</span>
        </div>

        {error && <p role="alert" className="mb-4 rounded-lg border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">{error}</p>}

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="animate-spin text-slate-500" size={24} /></div>
        ) : messages.length === 0 ? (
          <div className="rounded-xl border border-white/10 bg-white/5 p-12 text-center text-sm text-slate-500">
            Nenhuma mensagem recebida ainda.
          </div>
        ) : (
          <div className="space-y-3">
            {messages.map(m => (
              <div key={m.id} className="rounded-xl border border-white/10 bg-white/5 p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-white">{m.name}</span>
                      <span className={`rounded-full border px-2 py-0.5 text-[10px] font-medium ${STATUS_STYLES[m.status] || STATUS_STYLES.novo}`}>
                        {m.status}
                      </span>
                    </div>
                    <a href={`mailto:${m.email}`} className="mt-0.5 block truncate text-xs text-violet-300 hover:underline">{m.email}</a>
                  </div>
                  <span className="text-[11px] text-slate-500">{fmtDate(m.created_date)}</span>
                </div>

                <div className="mt-2 flex items-center gap-2 text-[11px] text-slate-500">
                  <span className="rounded bg-white/5 px-1.5 py-0.5">{m.category || '—'}</span>
                </div>

                <p className="mt-3 whitespace-pre-wrap rounded-lg bg-black/20 p-3 text-[13px] leading-relaxed text-slate-300">{m.message}</p>

                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <a
                    href={buildMailto(m)}
                    className="flex items-center gap-1.5 rounded-lg bg-violet-500 px-3 py-1.5 text-xs font-medium text-white transition hover:bg-violet-600"
                  >
                    <Mail size={13} /> Responder por e-mail
                  </a>
                  <div className="flex items-center gap-1 rounded-lg border border-white/10 bg-black/20 px-2 py-1">
                    <span className="text-[10px] text-slate-500">Status:</span>
                    <select
                      value={m.status}
                      disabled={updatingId === m.id}
                      onChange={e => updateStatus(m.id, e.target.value)}
                      className="bg-transparent text-xs text-white outline-none disabled:opacity-50"
                    >
                      {STATUS_OPTIONS.map(s => <option key={s} value={s} className="bg-[#0a0d15]">{s}</option>)}
                    </select>
                    {updatingId === m.id && <Loader2 size={11} className="animate-spin text-slate-500" />}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
