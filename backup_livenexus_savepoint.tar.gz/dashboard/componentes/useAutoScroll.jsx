import { useRef, useEffect, useCallback } from 'react';

/**
 * useAutoScroll — Hook padronizado de auto-scroll por proximidade das bordas do LiveNexus.
 *
 * Padrão validado no submenu Overlay e no Editor de Template:
 * - mouse próximo da borda superior → sobe suavemente;
 * - mouse próximo da borda inferior → desce suavemente;
 * - mouse fora dessas zonas ou fora do elemento → para imediatamente;
 * - chegou ao início ou ao final → para;
 * - mouse segurando botão (drag, seleção de texto, slider) → não movimenta;
 * - cursor sobre inputs, textareas, selects ou elementos interativos nativos → não movimenta;
 * - conteúdo vertical menor ou igual à área visível → não ativa;
 * - scrollbar visual oculta (classe 'no-scrollbar').
 *
 * @param {Object} options
 * @param {number} [options.zone=65] - Zona de proximidade em pixels.
 * @param {number} [options.minSpeed=1.0] - Velocidade mínima (pixels por frame).
 * @param {number} [options.maxSpeed=4.5] - Velocidade máxima (pixels por frame).
 * @param {boolean} [options.ignoreInputs=true] - Ignora auto-scroll em campos de texto/interação.
 * @param {boolean} [options.checkButtons=true] - Interrompe auto-scroll quando o mouse estiver pressionado.
 * @param {boolean} [options.enabled=true] - Habilita/desabilita o auto-scroll condicionalmente.
 * @param {React.RefObject} [options.externalRef] - Ref externa opcional.
 * @returns {{ ref: React.RefObject, handleMouseMove: Function, handleMouseLeave: Function, stopAutoScroll: Function }}
 */
export function useAutoScroll(options = {}) {
  const {
    zone = 65,
    minSpeed = 1.0,
    maxSpeed = 4.5,
    ignoreInputs = true,
    checkButtons = true,
    enabled = true,
    externalRef = null,
  } = options;

  const localRef = useRef(null);
  const containerRef = externalRef || localRef;
  const scrollSpeedRef = useRef(0);
  const animFrameRef = useRef(null);

  const stopAutoScroll = useCallback(() => {
    scrollSpeedRef.current = 0;
    if (animFrameRef.current !== null) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
  }, []);

  const startAutoScrollLoop = useCallback(() => {
    if (animFrameRef.current !== null) return;

    const loop = () => {
      const el = containerRef.current;
      if (scrollSpeedRef.current !== 0 && el) {
        // Para se atingir as extremidades do container
        if (scrollSpeedRef.current < 0 && el.scrollTop <= 0) {
          stopAutoScroll();
          return;
        }
        if (scrollSpeedRef.current > 0 && el.scrollTop + el.clientHeight >= el.scrollHeight - 1) {
          stopAutoScroll();
          return;
        }

        el.scrollTop += scrollSpeedRef.current;
        animFrameRef.current = requestAnimationFrame(loop);
      } else {
        animFrameRef.current = null;
      }
    };

    animFrameRef.current = requestAnimationFrame(loop);
  }, [containerRef, stopAutoScroll]);

  const handleMouseMove = useCallback((e) => {
    if (!enabled) return;
    const el = containerRef.current;
    if (!el) return;

    // Não acionar auto-scroll enquanto o usuário segura o botão do mouse (ex: arrastando slider, cores ou selecionando texto)
    if (checkButtons && e.buttons !== 0) {
      stopAutoScroll();
      return;
    }

    // Se o elemento diretamente sob o cursor for input, textarea, select ou tiver data-no-auto-scroll
    if (ignoreInputs) {
      const target = e.target;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'SELECT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable ||
          target.closest?.('input, select, textarea, [data-no-auto-scroll]'))
      ) {
        stopAutoScroll();
        return;
      }
    }

    // Se o conteúdo não transborda verticalmente, não há o que rolar
    if (el.scrollHeight <= el.clientHeight + 4) {
      stopAutoScroll();
      return;
    }

    const rect = el.getBoundingClientRect();
    const mouseY = e.clientY;
    const mouseX = e.clientX;

    // Verificar se o mouse está dentro dos limites da área
    if (
      mouseY < rect.top ||
      mouseY > rect.bottom ||
      mouseX < rect.left ||
      mouseX > rect.right
    ) {
      stopAutoScroll();
      return;
    }

    const effectiveZone = Math.min(zone, Math.floor(rect.height / 3));
    if (effectiveZone <= 0) {
      stopAutoScroll();
      return;
    }

    const distFromTop = mouseY - rect.top;
    const distFromBottom = rect.bottom - mouseY;

    if (distFromTop < effectiveZone && distFromTop >= 0) {
      // Proximidade da borda superior: sobe de forma suave e controlada
      if (el.scrollTop <= 0) {
        stopAutoScroll();
        return;
      }
      const factor = Math.max(0, Math.min(1, (effectiveZone - distFromTop) / effectiveZone));
      scrollSpeedRef.current = -(minSpeed + factor * (maxSpeed - minSpeed));
      startAutoScrollLoop();
    } else if (distFromBottom < effectiveZone && distFromBottom >= 0) {
      // Proximidade da borda inferior: desce de forma suave e controlada
      if (el.scrollTop + el.clientHeight >= el.scrollHeight - 1) {
        stopAutoScroll();
        return;
      }
      const factor = Math.max(0, Math.min(1, (effectiveZone - distFromBottom) / effectiveZone));
      scrollSpeedRef.current = (minSpeed + factor * (maxSpeed - minSpeed));
      startAutoScrollLoop();
    } else {
      // Zona neutra: para imediatamente
      stopAutoScroll();
    }
  }, [enabled, zone, minSpeed, maxSpeed, ignoreInputs, checkButtons, containerRef, startAutoScrollLoop, stopAutoScroll]);

  const handleMouseLeave = useCallback(() => {
    stopAutoScroll();
  }, [stopAutoScroll]);

  // Vincula os listeners nativos ao elemento da ref e aplica a classe no-scrollbar
  useEffect(() => {
    const el = containerRef.current;
    if (!el || !enabled) return;

    if (!el.classList.contains('no-scrollbar')) {
      el.classList.add('no-scrollbar');
    }

    const onMove = (e) => handleMouseMove(e);
    const onLeave = () => handleMouseLeave();

    el.addEventListener('mousemove', onMove, { passive: true });
    el.addEventListener('mouseleave', onLeave, { passive: true });

    return () => {
      stopAutoScroll();
      el.removeEventListener('mousemove', onMove);
      el.removeEventListener('mouseleave', onLeave);
    };
  }, [containerRef, enabled, handleMouseMove, handleMouseLeave, stopAutoScroll]);

  return {
    ref: containerRef,
    handleMouseMove,
    handleMouseLeave,
    stopAutoScroll,
  };
}

/**
 * AutoScrollContainer — Componente wrapper reutilizável que aplica auto-scroll por proximidade de borda.
 */
export function AutoScrollContainer({
  children,
  className = '',
  zone = 65,
  minSpeed = 1.0,
  maxSpeed = 4.5,
  ignoreInputs = true,
  checkButtons = true,
  enabled = true,
  as: Component = 'div',
  ...props
}) {
  const { ref } = useAutoScroll({
    zone,
    minSpeed,
    maxSpeed,
    ignoreInputs,
    checkButtons,
    enabled,
  });

  return (
    <Component
      ref={ref}
      className={`no-scrollbar overflow-y-auto overscroll-contain ${className}`}
      {...props}
    >
      {children}
    </Component>
  );
}

export default useAutoScroll;
