-- Existing authentication handlers read and write user_data alongside users and sessions.
CREATE TABLE IF NOT EXISTS user_data (
  user_id TEXT PRIMARY KEY,
  display_name TEXT,
  gallery TEXT DEFAULT '[]',
  user_library TEXT DEFAULT '{"songs":[],"albums":[],"artists":[],"playlists":[]}',
  rtc_registry TEXT DEFAULT '{"scenes":{},"overlays":{}}',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (user_id) REFERENCES users(id)
);
