-- D1 migration: add data JSON column to users table
ALTER TABLE users ADD COLUMN data TEXT NOT NULL DEFAULT '{}';
