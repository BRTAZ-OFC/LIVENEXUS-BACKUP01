import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'
import path from 'path'
import { fileURLToPath, pathToFileURL } from 'node:url'

function ytMusicPlugin() {
  return {
    name: 'ytmusic-bridge-plugin',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url.startsWith('/api/ytmusic')) {
          return next();
        }
        try {
          const { handleRequest } = await import('./dashboard/conexao/Connection_music-bridge.js');
          const protocol = req.headers['x-forwarded-proto'] || 'http';
          const host = req.headers.host || 'localhost:3000';
          const fullUrl = `${protocol}://${host}${req.url}`;

          let body = null;
          if (req.method === 'POST' || req.method === 'PUT') {
            const chunks = [];
            for await (const chunk of req) chunks.push(chunk);
            body = Buffer.concat(chunks).toString('utf-8');
          }

          const fetchReq = new Request(fullUrl, {
            method: req.method,
            headers: req.headers,
            body: body ? body : undefined,
          });

          const webRes = await handleRequest(fetchReq);
          res.statusCode = webRes.status;
          webRes.headers.forEach((val, key) => {
            res.setHeader(key, val);
          });
          const text = await webRes.text();
          res.end(text);
        } catch (err) {
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ ok: false, error: err.message || String(err) }));
        }
      });
    },
    configurePreviewServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url.startsWith('/api/ytmusic')) {
          return next();
        }
        try {
          const { handleRequest } = await import('./dashboard/conexao/Connection_music-bridge.js');
          const protocol = req.headers['x-forwarded-proto'] || 'http';
          const host = req.headers.host || 'localhost:3000';
          const fullUrl = `${protocol}://${host}${req.url}`;

          let body = null;
          if (req.method === 'POST' || req.method === 'PUT') {
            const chunks = [];
            for await (const chunk of req) chunks.push(chunk);
            body = Buffer.concat(chunks).toString('utf-8');
          }

          const fetchReq = new Request(fullUrl, {
            method: req.method,
            headers: req.headers,
            body: body ? body : undefined,
          });

          const webRes = await handleRequest(fetchReq);
          res.statusCode = webRes.status;
          webRes.headers.forEach((val, key) => {
            res.setHeader(key, val);
          });
          const text = await webRes.text();
          res.end(text);
        } catch (err) {
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ ok: false, error: err.message || String(err) }));
        }
      });
    },
  };
}

function cloudflareStatsPlugin() {
  return {
    name: 'cloudflare-stats-plugin',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url.startsWith('/api/cloudflare-stats')) {
          return next();
        }
        const token = process.env.CLOUDFLARE_API_TOKEN;
        const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
        const workerName = process.env.CLOUDFLARE_WORKER_NAME || '';

        if (!token || !accountId) {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          return res.end(JSON.stringify({ configured: false, reason: 'Missing CLOUDFLARE_API_TOKEN or CLOUDFLARE_ACCOUNT_ID' }));
        }

        try {
          const todayStr = new Date().toISOString().split('T')[0];
          const query = `
            query {
              viewer {
                accounts(filter: {accountTag: "${accountId}"}) {
                  workersInvocationsAdaptive(
                    limit: 100,
                    filter: {
                      date: "${todayStr}"
                      ${workerName ? `, scriptName: "${workerName}"` : ''}
                    }
                  ) {
                    sum {
                      requests
                    }
                  }
                }
              }
            }
          `;

          const cfRes = await fetch('https://api.cloudflare.com/client/v4/graphql', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ query }),
          });

          const cfData = await cfRes.json();
          const requestsToday = cfData?.data?.viewer?.accounts?.[0]?.workersInvocationsAdaptive?.[0]?.sum?.requests || 0;
          const limit = 100000;
          const usagePercent = Number(((requestsToday / limit) * 100).toFixed(2));

          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          return res.end(JSON.stringify({
            configured: true,
            requestsToday,
            limit,
            usagePercent,
          }));
        } catch (err) {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          return res.end(JSON.stringify({ configured: false, error: err.message || String(err) }));
        }
      });
    },
    configurePreviewServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url.startsWith('/api/cloudflare-stats')) {
          return next();
        }
        const token = process.env.CLOUDFLARE_API_TOKEN;
        const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
        const workerName = process.env.CLOUDFLARE_WORKER_NAME || '';

        if (!token || !accountId) {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          return res.end(JSON.stringify({ configured: false, reason: 'Missing CLOUDFLARE_API_TOKEN or CLOUDFLARE_ACCOUNT_ID' }));
        }

        try {
          const todayStr = new Date().toISOString().split('T')[0];
          const query = `
            query {
              viewer {
                accounts(filter: {accountTag: "${accountId}"}) {
                  workersInvocationsAdaptive(
                    limit: 100,
                    filter: {
                      date: "${todayStr}"
                      ${workerName ? `, scriptName: "${workerName}"` : ''}
                    }
                  ) {
                    sum {
                      requests
                    }
                  }
                }
              }
            }
          `;

          const cfRes = await fetch('https://api.cloudflare.com/client/v4/graphql', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${token}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ query }),
          });

          const cfData = await cfRes.json();
          const requestsToday = cfData?.data?.viewer?.accounts?.[0]?.workersInvocationsAdaptive?.[0]?.sum?.requests || 0;
          const limit = 100000;
          const usagePercent = Number(((requestsToday / limit) * 100).toFixed(2));

          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          return res.end(JSON.stringify({
            configured: true,
            requestsToday,
            limit,
            usagePercent,
          }));
        } catch (err) {
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          return res.end(JSON.stringify({ configured: false, error: err.message || String(err) }));
        }
      });
    },
  };
}

function youtubeTest1Plugin() {
  return {
    name: 'youtube-test1-lab-plugin',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url.startsWith('/api/admin/lab/youtube-test1/bootstrap')) {
          return next();
        }
        try {
          let identifier = '';
          const urlObj = new URL(req.url, 'http://localhost:3000');
          identifier = urlObj.searchParams.get('identifier') || '';

          if (!identifier && (req.method === 'POST' || req.method === 'PUT')) {
            const chunks = [];
            for await (const chunk of req) chunks.push(chunk);
            const bodyStr = Buffer.concat(chunks).toString('utf-8');
            try {
              const bodyJson = JSON.parse(bodyStr);
              identifier = bodyJson.identifier || '';
            } catch {
              identifier = bodyStr;
            }
          }

          const { resolveYouTubeLiveBootstrap } = await import('./dashboard/painel-admin/lab/Admin_youtubeTest1Bootstrap.js');
          const result = await resolveYouTubeLiveBootstrap(identifier);
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(result));
        } catch (err) {
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ ok: false, error: err.message || String(err) }));
        }
      });
    },
    configurePreviewServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url.startsWith('/api/admin/lab/youtube-test1/bootstrap')) {
          return next();
        }
        try {
          let identifier = '';
          const urlObj = new URL(req.url, 'http://localhost:3000');
          identifier = urlObj.searchParams.get('identifier') || '';

          if (!identifier && (req.method === 'POST' || req.method === 'PUT')) {
            const chunks = [];
            for await (const chunk of req) chunks.push(chunk);
            const bodyStr = Buffer.concat(chunks).toString('utf-8');
            try {
              const bodyJson = JSON.parse(bodyStr);
              identifier = bodyJson.identifier || '';
            } catch {
              identifier = bodyStr;
            }
          }

          const { resolveYouTubeLiveBootstrap } = await import('./dashboard/painel-admin/lab/Admin_youtubeTest1Bootstrap.js');
          const result = await resolveYouTubeLiveBootstrap(identifier);
          res.statusCode = 200;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify(result));
        } catch (err) {
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ ok: false, error: err.message || String(err) }));
        }
      });
    },
  };
}

function imageUploadPlugin() {
  const shouldSkip = (req) => {
    const urlPath = req.url.split('?')[0];
    if (urlPath.startsWith('/dashboard/Imagem/template/')) return true;
    if (/\.(jsx?|tsx?|json|css|svg)$/i.test(urlPath)) return true;
    if (req.url.includes('?import') || req.url.includes('&import')) return true;
    return false;
  };
  return {
    name: 'image-upload-lab-plugin',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (shouldSkip(req)) return next();
        const urlPath = req.url.split('?')[0];
        if (!urlPath.startsWith('/api/admin/lab/image-upload') && !urlPath.startsWith('/dashboard/Imagem/')) {
          return next();
        }
        try {
          const { handleImageUploadRequest } = await import('./dashboard/painel-admin/lab/imageUploadHandler.js');
          await handleImageUploadRequest(req, res, next);
        } catch (err) {
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ ok: false, error: err.message || String(err) }));
        }
      });
    },
    configurePreviewServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (shouldSkip(req)) return next();
        const urlPath = req.url.split('?')[0];
        if (!urlPath.startsWith('/api/admin/lab/image-upload') && !urlPath.startsWith('/dashboard/Imagem/')) {
          return next();
        }
        try {
          const { handleImageUploadRequest } = await import('./dashboard/painel-admin/lab/imageUploadHandler.js');
          await handleImageUploadRequest(req, res, next);
        } catch (err) {
          res.statusCode = 500;
          res.setHeader('Content-Type', 'application/json');
          res.end(JSON.stringify({ ok: false, error: err.message || String(err) }));
        }
      });
    },
  };
}

function userGalleryPlugin() {
  async function handleGallery(req, res, next) {
    if (!req.url.startsWith('/api/admin/lab/user-gallery')) return next();
    const { handleUserGalleryRequest } = await import('./dashboard/painel-admin/lab/userGalleryHandler.js');
    await handleUserGalleryRequest(req, res);
  }
  return {
    name: 'user-gallery-plugin',
    configureServer(server) {
      server.middlewares.use(handleGallery);
    },
    configurePreviewServer(server) { server.middlewares.use(handleGallery); },
  };
}

function templatesPlugin() {
  const handle = async (req, res, next) => {
    if (!req.url.split('?')[0].startsWith('/api/templates')) return next();
    const { handleTemplateRequest } = await import('./dashboard/Imagem/template/Template_Handler.js');
    await handleTemplateRequest(req, res);
  };
  return {
    name: 'templates-plugin',
    configureServer(server) { server.middlewares.use(handle); },
    configurePreviewServer(server) { server.middlewares.use(handle); },
  };
}

function documentaryDomainsPlugin() {
  async function handle(req, res, next) {
    const pathname = req.url.split('?')[0];
    if (pathname === '/api/overlays') {
      const { handleOverlayRequest } = await import('./dashboard/overlays/Overlay_Handler.js');
      return handleOverlayRequest(req, res);
    }
    if (pathname === '/api/library') {
      const { handleLibraryRequest } = await import('./dashboard/biblioteca/Library_Handler.js');
      return handleLibraryRequest(req, res);
    }
    if (pathname === '/api/contacts') {
      const { handleMessagesRequest } = await import('./dashboard/configuracao/Config_MessagesHandler.js');
      return handleMessagesRequest(req, res);
    }
    if (pathname === '/api/live-sessions') {
      const { handleVodsRequest } = await import('./dashboard/configuracao/Config_VodsHandler.js');
      return handleVodsRequest(req, res);
    }
    if (pathname === '/api/reviews') {
      const { handleReviewsRequest } = await import('./dashboard/painel-admin/Review_Handler.js');
      return handleReviewsRequest(req, res);
    }
    next();
  }
  return {
    name: 'documentary-domains-plugin',
    configureServer(server) { server.middlewares.use(handle); },
    configurePreviewServer(server) { server.middlewares.use(handle); },
  };
}

function cenariosPlugin() {
  return {
    name: 'cenarios-plugin',
    configureServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url.startsWith('/api/cenarios')) return next();
        const { handleCenariosRequest } = await import('./dashboard/painel-admin/db/cenariosHandler.js');
        await handleCenariosRequest(req, res);
      });
    },
    configurePreviewServer(server) {
      server.middlewares.use(async (req, res, next) => {
        if (!req.url.startsWith('/api/cenarios')) return next();
        const { handleCenariosRequest } = await import('./dashboard/painel-admin/db/cenariosHandler.js');
        await handleCenariosRequest(req, res);
      });
    }
  };
}

function authRoutesPlugin() {
  let platformProxy;
  async function attach(server) {
    try {
      const { getPlatformProxy } = await import('wrangler');
      console.log('DEBUG: Checking environment variables...');
      console.log('DEBUG: CLOUDFLARE_API_TOKEN exists:', !!process.env.CLOUDFLARE_API_TOKEN);
      console.log('DEBUG: CLOUDFLARE_ACCOUNT_ID exists:', !!process.env.CLOUDFLARE_ACCOUNT_ID);
      console.log('DEBUG: CWD is:', process.cwd());
      platformProxy = await getPlatformProxy({
        configPath: fileURLToPath(new URL('./wrangler.toml', import.meta.url)),
        remoteBindings: ['DB'],
        account_id: process.env.CLOUDFLARE_ACCOUNT_ID,
        persist: false,
      });
      console.log('DEBUG: Proxy initialized. Keys in platformProxy.env:', Object.keys(platformProxy.env));
      if (platformProxy.env.DB) {
          console.log('DEBUG: DB binding found. It is an object:', typeof platformProxy.env.DB === 'object');
      } else {
          console.error('DEBUG: DB binding MISSING.');
      }
    } catch (e) {
      console.error('DEBUG: Critical error in getPlatformProxy:', e);
      // ...
    }
    server.middlewares.use(handle);
  }
  const routes = {
    '/api/auth/login': './dashboard/api/auth/login.js',
    '/api/auth/register': './dashboard/api/auth/register.js',
    '/api/auth/me': './dashboard/api/auth/me.js',
    '/api/auth/update-me': './dashboard/api/auth/update-me.js',
    '/api/auth/logout': './dashboard/api/auth/logout.js',
  };
  async function handle(req, res, next) {
    try {
      const pathname = new URL(req.url, 'http://localhost').pathname;
      if (!pathname.startsWith('/api/')) return next();
      // Only the real session handler may identify a documentary owner.
      const { resolveSessionId, getSession } = await import('./dashboard/api/auth/_lib.js');
      const env = platformProxy ? platformProxy.env : { DB: null };
      const requestUrl = `http://${req.headers.host || 'localhost:3000'}${req.url}`;
      const request = new Request(requestUrl, { method: req.method, headers: req.headers });
      const sessionId = resolveSessionId(request, env);
      const session = env.DB && sessionId ? await getSession(env, sessionId) : null;
      req.documentUserId = session?.id || null;
      req.documentUserRole = session?.role || null;

      if (!routes[pathname]) return next();
      const route = await import(pathToFileURL(path.resolve(process.cwd(), routes[pathname])).href);
      const method = req.method[0] + req.method.slice(1).toLowerCase();
      const handler = route[`onRequest${method}`];
      if (!handler) {
        res.statusCode = 405;
        return res.end(JSON.stringify({ error: 'Método não permitido.' }));
      }
      const chunks = req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS'
        ? [] : await Array.fromAsync(req);
      const routeRequest = new Request(requestUrl, {
        method: req.method,
        headers: req.headers,
        ...(chunks.length ? { body: Buffer.concat(chunks) } : {}),
      });
      const response = await handler({ request: routeRequest, env });
      res.statusCode = response.status;
      response.headers.forEach((value, key) => res.setHeader(key, value));
      return res.end(Buffer.from(await response.arrayBuffer()));
    } catch (error) {
      res.statusCode = 500;
      res.setHeader('Content-Type', 'application/json');
      return res.end(JSON.stringify({ error: error.message }));
    }
  }
  return {
    name: 'original-auth-routes-plugin',
    configureServer: attach,
    configurePreviewServer: attach,
  };
}

// https://vite.dev/config/
export default defineConfig({
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './dashboard'),
      '@dashboard': path.resolve(__dirname, './dashboard'),
    },
  },
  plugins: [
    authRoutesPlugin(),
    ytMusicPlugin(),
    cloudflareStatsPlugin(),
    youtubeTest1Plugin(),
    templatesPlugin(),
    imageUploadPlugin(),
    userGalleryPlugin(),
    cenariosPlugin(),
    documentaryDomainsPlugin(),
    react(),
  ],
  server: {
    host: '0.0.0.0',
    port: 3000,
    allowedHosts: true,
  },
  preview: {
    host: '0.0.0.0',
    port: 3000,
  }
});